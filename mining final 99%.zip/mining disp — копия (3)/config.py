from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "raw"
MODEL_DIR = BASE_DIR / "saved_models"
DB_PATH = DATA_DIR / "monitoring.db"

for folder in (DATA_DIR, RAW_DATA_DIR, MODEL_DIR):
    folder.mkdir(parents=True, exist_ok=True)
