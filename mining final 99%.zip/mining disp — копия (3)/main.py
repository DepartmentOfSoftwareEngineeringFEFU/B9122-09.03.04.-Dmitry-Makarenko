from database.db import init_db
from database.seed import seed_demo_data
from ui.app import MonitoringApp


def main():
    init_db()
    seed_demo_data()
    app = MonitoringApp()
    app.mainloop()


if __name__ == "__main__":
    main()
