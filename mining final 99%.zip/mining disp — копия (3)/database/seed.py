from datetime import date
from database.db import get_connection


def seed_demo_data():
    conn = get_connection()
    cur = conn.cursor()

    machines_count = cur.execute("SELECT COUNT(*) AS c FROM machines").fetchone()["c"]
    if machines_count > 0:
        conn.close()
        return

    machines = [
        ("Самосвал Б707", "БелАЗ 75131", "Карьерный самосвал", "active"),
        ("Самосвал Б708", "БелАЗ 7530", "Карьерный самосвал", "active"),
        ("Самосвал Б709", "Komatsu HD785", "Карьерный самосвал", "active"),
    ]
    machine_ids = {}

    for name, model, machine_type, status in machines:
        cur.execute(
            "INSERT INTO machines (name, model, type, status) VALUES (?, ?, ?, ?)",
            (name, model, machine_type, status)
        )
        machine_ids[name] = cur.lastrowid

    mechanics = [
        ("Валентин Механикович Карданович", "Механик по ремонту горной техники", "+7-900-111-22-33", "kardanovich@example.com"),
        ("Игорь Петрович Редукторов", "Механик участка", "+7-900-222-33-44", "reduktorov@example.com"),
        ("Алексей Сергеевич Турбин", "Старший механик", "+7-900-333-44-55", "turbin@example.com"),
    ]
    mechanic_ids = {}

    for full_name, position, phone, email in mechanics:
        cur.execute(
            "INSERT INTO mechanics (full_name, position, phone, email) VALUES (?, ?, ?, ?)",
            (full_name, position, phone, email)
        )
        mechanic_ids[full_name] = cur.lastrowid

    assignments = [
        ("Самосвал Б707", "Валентин Механикович Карданович"),
        ("Самосвал Б708", "Игорь Петрович Редукторов"),
        ("Самосвал Б709", "Алексей Сергеевич Турбин"),
    ]

    for machine_name, mechanic_name in assignments:
        cur.execute(
            "INSERT INTO machine_mechanics (machine_id, mechanic_id, assignment_date) VALUES (?, ?, ?)",
            (machine_ids[machine_name], mechanic_ids[mechanic_name], date.today().isoformat())
        )

    cur.execute(
        "INSERT INTO units (machine_id, name, unit_type, status) VALUES (?, ?, ?, ?)",
        (machine_ids["Самосвал Б707"], "Редуктор", "Редуктор", "active")
    )
    unit_id = cur.lastrowid

    cur.execute(
        "INSERT INTO sensors (unit_id, name, sensor_type, install_date) VALUES (?, ?, ?, ?)",
        (unit_id, "A603C01", "Вибродатчик", date.today().isoformat())
    )

    conn.commit()
    conn.close()
