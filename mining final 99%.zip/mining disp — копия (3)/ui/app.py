# ui/app.py
import sys
import os
import random
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Добавляем корневую папку проекта в путь поиска модулей
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.db import get_connection
from services.data_loader import load_sensor_csv
from models.ml_model import load_model_for_sensor
from services.analysis_service import (
    get_sensor_values,
    analyze_signal_segment,
    get_latest_sensor_verdict,
    get_analysis_history
)


class MonitoringApp(tk.Tk):
    """Главное окно программной системы мониторинга состояния горной техники."""

    STATE_LEVELS = {"normal": 0, "wear": 1, "fault": 2}
    STATE_NAMES = {"normal": "Норма", "wear": "Износ", "fault": "Сильный износ"}

    def __init__(self):
        super().__init__()

        self.title("Система мониторинга состояния горной техники")
        self.geometry("1400x800")
        self.minsize(1200, 700)

        self.conn = get_connection()

        self.current_machine_id = None
        self.current_unit_id = None
        self.current_sensor_id = None
        self.current_frame = None

        self.analysis_running = False
        self.analysis_job = None
        self.analysis_interval_ms = 5000

        self._setup_style()
        self._setup_ui()

        self.refresh_object_tree()
        self.refresh_notifications()

    # ------------------------------------------------------------------
    # ОБЩИЙ СТИЛЬ
    # ------------------------------------------------------------------

    def _setup_style(self):
        style = ttk.Style(self)

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", font=("Arial", 10))
        style.configure("TButton", padding=5)
        style.configure("Treeview", rowheight=26)
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"))
        style.configure("Title.TLabel", font=("Arial", 13, "bold"))
        style.configure("Block.TLabelframe.Label", font=("Arial", 10, "bold"))

    # ------------------------------------------------------------------
    # ОСНОВНОЕ ОКНО
    # ------------------------------------------------------------------

    def _setup_ui(self):
        main_container = ttk.Frame(self)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Левая область: меню + дерево техники/узлов/датчиков
        left_panel = ttk.Frame(main_container, width=300)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))
        left_panel.pack_propagate(False)

        menu_frame = ttk.LabelFrame(left_panel, text="Меню", style="Block.TLabelframe")
        menu_frame.pack(fill=tk.X, pady=(0, 5))

        ttk.Button(menu_frame, text="Главный экран", command=self.show_main_screen).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Добавить объект мониторинга", command=self.show_add_monitoring_object).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Загрузить архив CSV", command=self.load_csv_data).pack(fill=tk.X, padx=5, pady=2)

        self.start_analysis_button = ttk.Button(
            menu_frame,
            text="Запустить анализ",
            command=self.start_continuous_analysis
        )
        self.start_analysis_button.pack(fill=tk.X, padx=5, pady=2)

        self.stop_analysis_button = ttk.Button(
            menu_frame,
            text="Остановить анализ",
            command=self.stop_continuous_analysis
        )
        self.stop_analysis_button.pack(fill=tk.X, padx=5, pady=2)

        ttk.Button(menu_frame, text="Просмотр БД", command=self.show_database_view).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Изменить справочники", command=self.show_directories_editor).pack(fill=tk.X, padx=5, pady=2)

        self.analysis_status_label = ttk.Label(menu_frame, text="Анализ остановлен")
        self.analysis_status_label.pack(fill=tk.X, padx=5, pady=(5, 3))

        object_frame = ttk.LabelFrame(left_panel, text="Техника, узлы и датчики", style="Block.TLabelframe")
        object_frame.pack(fill=tk.BOTH, expand=True)

        self.object_tree = ttk.Treeview(object_frame, show="tree", height=20)
        self.object_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        object_scroll = ttk.Scrollbar(object_frame, orient=tk.VERTICAL, command=self.object_tree.yview)
        object_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.object_tree.configure(yscrollcommand=object_scroll.set)

        self.object_tree.tag_configure("normal", background="#FFFFFF")
        self.object_tree.tag_configure("wear", background="#FFF4CC")
        self.object_tree.tag_configure("fault", background="#FFD6D6")
        self.object_tree.tag_configure("nodata", background="#FFFFFF")
        self.object_tree.bind("<<TreeviewSelect>>", self.on_object_tree_select)

        # Центральная область
        self.center_panel = ttk.Frame(main_container)
        self.center_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Правая область: оповещения диспетчеру
        right_panel = ttk.Frame(main_container, width=350)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 0))
        right_panel.pack_propagate(False)

        notifications_frame = ttk.LabelFrame(right_panel, text="Оповещения диспетчеру", style="Block.TLabelframe")
        notifications_frame.pack(fill=tk.BOTH, expand=True)

        self.notifications_listbox = tk.Listbox(
            notifications_frame,
            height=25,
            font=("Arial", 10),
            activestyle="none"
        )
        self.notifications_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        notif_scroll = ttk.Scrollbar(notifications_frame, orient=tk.VERTICAL, command=self.notifications_listbox.yview)
        notif_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.notifications_listbox.configure(yscrollcommand=notif_scroll.set)

        self.show_main_screen()

    def clear_center(self):
        for widget in self.center_panel.winfo_children():
            widget.destroy()

    def _refresh_all(self):
        self.refresh_object_tree()
        self.refresh_notifications()

        if hasattr(self, "main_tree"):
            self.refresh_main_table()

        if self.current_frame == "database":
            self.update_db_view()

    def _get_state_tag(self, state_text):
        text = str(state_text or "").lower()

        if "силь" in text or "fault" in text or "крит" in text:
            return "fault"
        if "износ" in text or "wear" in text:
            return "wear"
        if "норма" in text or "normal" in text:
            return "normal"

        return "nodata"

    def _get_latest_state_for_sensor(self, sensor_id):
        verdict = get_latest_sensor_verdict(self.conn, sensor_id)
        if verdict:
            return verdict.get("state_name_ru", "Нет данных")
        return "Нет данных"

    # ------------------------------------------------------------------
    # ФИЛЬТР ПО ДАТЕ
    # ------------------------------------------------------------------

    def _reset_date_filter(self):
        """Сбрасывает фильтр по датам в просмотре базы данных."""
        if hasattr(self, "date_from_var"):
            self.date_from_var.set("")

        if hasattr(self, "date_to_var"):
            self.date_to_var.set("")

        self.update_db_view()

    def _get_date_filter_values(self):
        """Возвращает значения фильтра по датам в формате YYYY-MM-DD."""
        date_from = self.date_from_var.get().strip() if hasattr(self, "date_from_var") else ""
        date_to = self.date_to_var.get().strip() if hasattr(self, "date_to_var") else ""

        for value, label in [(date_from, "Дата с"), (date_to, "Дата по")]:
            if value:
                try:
                    datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror(
                        "Ошибка даты",
                        f"{label} должна быть указана в формате ГГГГ-ММ-ДД, например 2026-06-25."
                    )
                    return None, None

        return date_from, date_to

    def _date_in_range(self, date_value):
        """
        Проверяет, попадает ли дата в указанный диапазон.
        Работает с ISO-строками вида YYYY-MM-DDTHH:MM:SS и YYYY-MM-DD HH:MM:SS.
        """
        date_from, date_to = self._get_date_filter_values()

        if date_from is None and date_to is None:
            return False

        if not date_value:
            return True

        date_part = str(date_value)[:10]

        if date_from and date_part < date_from:
            return False

        if date_to and date_part > date_to:
            return False

        return True

    # ------------------------------------------------------------------
    # ЛЕВОЕ ДЕРЕВО ОБЪЕКТОВ
    # ------------------------------------------------------------------

    def refresh_object_tree(self):
        if not hasattr(self, "object_tree"):
            return

        self.object_tree.delete(*self.object_tree.get_children())

        cursor = self.conn.cursor()
        machines = cursor.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()

        for machine in machines:
            machine_id = machine["machine_id"]

            machine_node = self.object_tree.insert(
                "",
                tk.END,
                iid=f"machine_{machine_id}",
                text=f"{machine['name']} ({machine['model'] or '-'})",
                open=True
            )

            units = cursor.execute(
                "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
                (machine_id,)
            ).fetchall()

            for unit in units:
                sensor = cursor.execute(
                    "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                    (unit["unit_id"],)
                ).fetchone()

                state_text = "Нет данных"
                tag = "nodata"

                if sensor:
                    state_text = self._get_latest_state_for_sensor(sensor["sensor_id"])
                    tag = self._get_state_tag(state_text)

                unit_node = self.object_tree.insert(
                    machine_node,
                    tk.END,
                    iid=f"unit_{unit['unit_id']}",
                    text=f"{unit['name']} / {unit['unit_type']} — {state_text}",
                    open=True,
                    tags=(tag,)
                )

                if sensor:
                    self.object_tree.insert(
                        unit_node,
                        tk.END,
                        iid=f"sensor_{sensor['sensor_id']}",
                        text=f"Датчик: {sensor['name']} (ID {sensor['sensor_id']})",
                        tags=(tag,)
                    )

    def on_object_tree_select(self, event):
        selected = self.object_tree.selection()
        if not selected:
            return

        item_id = selected[0]

        if item_id.startswith("machine_"):
            self.current_machine_id = int(item_id.replace("machine_", ""))
            self.current_unit_id = None
            self.current_sensor_id = None
            self.show_machine_details()

        elif item_id.startswith("unit_"):
            self.current_unit_id = int(item_id.replace("unit_", ""))
            self._set_current_by_unit()
            self.show_unit_details()

        elif item_id.startswith("sensor_"):
            self.current_sensor_id = int(item_id.replace("sensor_", ""))
            self._set_current_by_sensor()
            self.show_unit_details()

    def _set_current_by_unit(self):
        cursor = self.conn.cursor()
        unit = cursor.execute(
            "SELECT * FROM units WHERE unit_id = ?",
            (self.current_unit_id,)
        ).fetchone()

        if unit:
            self.current_machine_id = unit["machine_id"]

        sensor = cursor.execute(
            "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
            (self.current_unit_id,)
        ).fetchone()

        if sensor:
            self.current_sensor_id = sensor["sensor_id"]

    def _set_current_by_sensor(self):
        cursor = self.conn.cursor()
        row = cursor.execute("""
            SELECT u.unit_id, u.machine_id
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            WHERE s.sensor_id = ?
        """, (self.current_sensor_id,)).fetchone()

        if row:
            self.current_unit_id = row["unit_id"]
            self.current_machine_id = row["machine_id"]

    # ------------------------------------------------------------------
    # ГЛАВНЫЙ ЭКРАН
    # ------------------------------------------------------------------

    def show_main_screen(self):
        self.clear_center()
        self.current_frame = "main"

        ttk.Label(
            self.center_panel,
            text="Главный экран диспетчера",
            style="Title.TLabel"
        ).pack(anchor=tk.W, pady=(0, 5))

        table_frame = ttk.LabelFrame(
            self.center_panel,
            text="Контролируемая техника",
            style="Block.TLabelframe"
        )
        table_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        columns = ("machine", "unit", "sensor", "state", "updated")
        self.main_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)

        self.main_tree.heading("machine", text="Техника")
        self.main_tree.heading("unit", text="Контролируемый узел")
        self.main_tree.heading("sensor", text="Датчик")
        self.main_tree.heading("state", text="Состояние")
        self.main_tree.heading("updated", text="Последнее обновление")

        self.main_tree.column("machine", width=180)
        self.main_tree.column("unit", width=160)
        self.main_tree.column("sensor", width=130)
        self.main_tree.column("state", width=130)
        self.main_tree.column("updated", width=160)

        self.main_tree.tag_configure("normal", background="#FFFFFF")
        self.main_tree.tag_configure("wear", background="#FFF4CC")
        self.main_tree.tag_configure("fault", background="#FFD6D6")
        self.main_tree.tag_configure("nodata", background="#FFFFFF")

        main_scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.main_tree.yview)
        self.main_tree.configure(yscrollcommand=main_scroll.set)

        self.main_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        main_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.main_tree.bind("<<TreeviewSelect>>", self.on_main_table_select)

        details_frame = ttk.LabelFrame(
            self.center_panel,
            text="Выбранная техника и последний анализ",
            style="Block.TLabelframe"
        )
        details_frame.pack(fill=tk.BOTH, expand=True)

        self.details_text = tk.Text(details_frame, height=10, font=("Arial", 10), wrap=tk.WORD)
        self.details_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.refresh_main_table()

    def refresh_main_table(self):
        if not hasattr(self, "main_tree"):
            return

        self.main_tree.delete(*self.main_tree.get_children())

        cursor = self.conn.cursor()
        rows = cursor.execute("""
            SELECT
                m.machine_id,
                m.name AS machine_name,
                u.unit_id,
                u.name AS unit_name,
                u.unit_type,
                s.sensor_id,
                s.name AS sensor_name
            FROM machines m
            LEFT JOIN units u ON u.machine_id = m.machine_id
            LEFT JOIN sensors s ON s.unit_id = u.unit_id
            ORDER BY m.machine_id, u.unit_id, s.sensor_id
        """).fetchall()

        for row in rows:
            state_text = "Нет данных"
            updated = "-"

            if row["sensor_id"]:
                verdict = get_latest_sensor_verdict(self.conn, row["sensor_id"])
                if verdict:
                    state_text = verdict.get("state_name_ru", "Нет данных")
                    updated = verdict.get("analysis_time", "-")

            tag = self._get_state_tag(state_text)
            item_id = f"row_{row['machine_id']}_{row['unit_id'] or 0}_{row['sensor_id'] or 0}"

            self.main_tree.insert(
                "",
                tk.END,
                iid=item_id,
                values=(
                    row["machine_name"] or "-",
                    row["unit_name"] or "-",
                    row["sensor_name"] or "-",
                    state_text,
                    updated
                ),
                tags=(tag,)
            )

    def on_main_table_select(self, event):
        selected = self.main_tree.selection()
        if not selected:
            return

        parts = selected[0].split("_")

        try:
            self.current_machine_id = int(parts[1])
            self.current_unit_id = int(parts[2]) if int(parts[2]) != 0 else None
            self.current_sensor_id = int(parts[3]) if int(parts[3]) != 0 else None
        except Exception:
            return

        if self.current_unit_id:
            self.show_unit_details()
        else:
            self.show_machine_details()

    def show_machine_details(self):
        if not self.current_machine_id:
            return

        if self.current_frame != "main":
            self.show_main_screen()

        cursor = self.conn.cursor()
        machine = cursor.execute(
            "SELECT * FROM machines WHERE machine_id = ?",
            (self.current_machine_id,)
        ).fetchone()

        if not machine:
            return

        units = cursor.execute(
            "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
            (self.current_machine_id,)
        ).fetchall()

        text = ""
        text += f"Наименование: {machine['name']}\n"
        text += f"Модель: {machine['model'] or '-'}\n"
        text += f"Тип: {machine['type'] or '-'}\n"
        text += f"Статус: {machine['status'] or '-'}\n\n"
        text += "Состояние узлов:\n"

        for unit in units:
            sensor = cursor.execute(
                "SELECT * FROM sensors WHERE unit_id = ?",
                (unit["unit_id"],)
            ).fetchone()

            state_text = "Нет данных"

            if sensor:
                state_text = self._get_latest_state_for_sensor(sensor["sensor_id"])

            text += f"- {unit['name']} ({unit['unit_type']}): {state_text}\n"

        self.details_text.delete(1.0, tk.END)
        self.details_text.insert(1.0, text)

    def show_unit_details(self):
        if not self.current_unit_id:
            return

        if self.current_frame != "main":
            self.show_main_screen()

        cursor = self.conn.cursor()

        row = cursor.execute("""
            SELECT
                m.name AS machine_name,
                m.model,
                m.type,
                m.status,
                u.name AS unit_name,
                u.unit_type,
                s.sensor_id,
                s.name AS sensor_name
            FROM units u
            JOIN machines m ON u.machine_id = m.machine_id
            LEFT JOIN sensors s ON s.unit_id = u.unit_id
            WHERE u.unit_id = ?
        """, (self.current_unit_id,)).fetchone()

        if not row:
            return

        text = ""
        text += f"Техника: {row['machine_name']}\n"
        text += f"Модель: {row['model'] or '-'}\n"
        text += f"Тип техники: {row['type'] or '-'}\n"
        text += f"Статус техники: {row['status'] or '-'}\n\n"
        text += f"Контролируемый узел: {row['unit_name']}\n"
        text += f"Тип узла: {row['unit_type']}\n"
        text += f"Датчик: {row['sensor_name'] or '-'}\n"

        if row["sensor_id"]:
            verdict = get_latest_sensor_verdict(self.conn, row["sensor_id"])
            text += "\nПоследний результат анализа:\n"

            if verdict:
                text += f"Состояние: {verdict.get('state_name_ru', 'Нет данных')}\n"
                text += f"Уверенность: {verdict.get('average_probability', 0):.2f}\n"
                text += f"Дата/время анализа: {verdict.get('analysis_time', '-')}\n"
                text += f"Рекомендация: {verdict.get('recommendation', '-')}\n"
            else:
                text += "Нет данных анализа.\n"

        self.details_text.delete(1.0, tk.END)
        self.details_text.insert(1.0, text)

    # ------------------------------------------------------------------
    # ПОСТОЯННЫЙ АНАЛИЗ
    # ------------------------------------------------------------------

    def start_continuous_analysis(self):
        if self.analysis_running:
            messagebox.showinfo("Анализ", "Постоянный анализ уже запущен.")
            return

        self.analysis_running = True
        self.analysis_status_label.config(text="Анализ запущен")
        self._continuous_analysis_step()

    def stop_continuous_analysis(self):
        self.analysis_running = False

        if self.analysis_job is not None:
            try:
                self.after_cancel(self.analysis_job)
            except Exception:
                pass
            self.analysis_job = None

        self.analysis_status_label.config(text="Анализ остановлен")

    def _continuous_analysis_step(self):
        if not self.analysis_running:
            return

        try:
            self._simulate_incoming_sensor_data()
            self._run_analysis_once(show_message=False)
            self._refresh_all()
        except Exception as e:
            self.stop_continuous_analysis()
            messagebox.showerror("Ошибка анализа", str(e))
            return

        self.analysis_job = self.after(self.analysis_interval_ms, self._continuous_analysis_step)

    def _simulate_incoming_sensor_data(self):
        cursor = self.conn.cursor()
        sensors = cursor.execute("""
            SELECT
                s.sensor_id,
                u.unit_type
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            ORDER BY s.sensor_id
        """).fetchall()

        if not sensors:
            return

        for sensor in sensors:
            sensor_id = sensor["sensor_id"]
            unit_type = sensor["unit_type"]
            now = datetime.now().isoformat(timespec="seconds")

            if unit_type == "Двигатель":
                base = random.uniform(0.10, 0.45)
            elif unit_type == "Редуктор":
                base = random.uniform(0.05, 0.35)
            elif unit_type == "Турбина":
                base = random.uniform(0.04, 0.30)
            else:
                base = random.uniform(0.05, 0.30)

            for _ in range(32):
                value = base + random.uniform(-0.05, 0.05)
                cursor.execute(
                    "INSERT INTO sensor_readings (sensor_id, timestamp, value) VALUES (?, ?, ?)",
                    (sensor_id, now, float(value))
                )

        self.conn.commit()

    def _run_analysis_once(self, show_message=True):
        cursor = self.conn.cursor()
        sensors = cursor.execute("SELECT sensor_id FROM sensors ORDER BY sensor_id").fetchall()

        if not sensors:
            if show_message:
                messagebox.showwarning("Внимание", "Нет датчиков для анализа.")
            return

        analyzed = 0
        errors = []

        for sensor in sensors:
            sensor_id = sensor["sensor_id"]

            try:
                values = get_sensor_values(self.conn, sensor_id)

                if len(values) < 128:
                    continue

                model = load_model_for_sensor(self.conn, sensor_id)
                results = analyze_signal_segment(self.conn, model, sensor_id, values)

                if results:
                    analyzed += 1

            except Exception as e:
                errors.append(f"Датчик {sensor_id}: {str(e)}")

        if show_message:
            if errors:
                messagebox.showwarning(
                    "Анализ выполнен частично",
                    f"Проанализировано датчиков: {analyzed}\n\nОшибки:\n" + "\n".join(errors[:5])
                )
            else:
                messagebox.showinfo("Готово", f"Анализ выполнен для датчиков: {analyzed}")

    def run_analysis(self):
        self.start_continuous_analysis()

    # ------------------------------------------------------------------
    # ФОРМЫ ДОБАВЛЕНИЯ И ИЗМЕНЕНИЯ
    # ------------------------------------------------------------------

    def _open_machine_form(self, refresh_callback, machine_id=None):
        win = tk.Toplevel(self)
        win.title("Техника")
        win.geometry("520x320")
        win.transient(self)
        win.grab_set()

        data = None
        if machine_id is not None:
            data = self.conn.execute(
                "SELECT * FROM machines WHERE machine_id = ?",
                (machine_id,)
            ).fetchone()

        ttk.Label(win, text="Наименование техники:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        name_entry = ttk.Entry(win)
        name_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Модель:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        model_entry = ttk.Entry(win)
        model_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Тип техники:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        type_entry = ttk.Entry(win)
        type_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Статус:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        status_entry = ttk.Entry(win)
        status_entry.pack(fill=tk.X, padx=10)

        if data:
            name_entry.insert(0, data["name"] or "")
            model_entry.insert(0, data["model"] or "")
            type_entry.insert(0, data["type"] or "")
            status_entry.insert(0, data["status"] or "")

        def save():
            name = name_entry.get().strip()
            model = model_entry.get().strip()
            type_ = type_entry.get().strip()
            status = status_entry.get().strip() or "active"

            if not name:
                messagebox.showerror("Ошибка", "Введите наименование техники.")
                return

            if machine_id is None:
                self.conn.execute(
                    "INSERT INTO machines (name, model, type, status) VALUES (?, ?, ?, ?)",
                    (name, model, type_, status)
                )
            else:
                self.conn.execute(
                    "UPDATE machines SET name = ?, model = ?, type = ?, status = ? WHERE machine_id = ?",
                    (name, model, type_, status, machine_id)
                )

            self.conn.commit()
            refresh_callback()
            self._refresh_all()
            win.destroy()

        ttk.Button(win, text="Сохранить", command=save).pack(fill=tk.X, padx=10, pady=(20, 5))
        ttk.Button(win, text="Отмена", command=win.destroy).pack(fill=tk.X, padx=10, pady=5)

    def _open_mechanic_form(self, refresh_callback, mechanic_id=None):
        win = tk.Toplevel(self)
        win.title("Механик")
        win.geometry("520x340")
        win.transient(self)
        win.grab_set()

        data = None
        if mechanic_id is not None:
            data = self.conn.execute(
                "SELECT * FROM mechanics WHERE mechanic_id = ?",
                (mechanic_id,)
            ).fetchone()

        ttk.Label(win, text="ФИО механика:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        full_name_entry = ttk.Entry(win)
        full_name_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Должность:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        position_entry = ttk.Entry(win)
        position_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Телефон:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        phone_entry = ttk.Entry(win)
        phone_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="E-mail:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        email_entry = ttk.Entry(win)
        email_entry.pack(fill=tk.X, padx=10)

        if data:
            full_name_entry.insert(0, data["full_name"] or "")
            position_entry.insert(0, data["position"] or "")
            phone_entry.insert(0, data["phone"] or "")
            email_entry.insert(0, data["email"] or "")

        def save():
            full_name = full_name_entry.get().strip()
            position = position_entry.get().strip()
            phone = phone_entry.get().strip()
            email = email_entry.get().strip()

            if not full_name:
                messagebox.showerror("Ошибка", "Введите ФИО механика.")
                return

            if mechanic_id is None:
                self.conn.execute(
                    "INSERT INTO mechanics (full_name, position, phone, email) VALUES (?, ?, ?, ?)",
                    (full_name, position, phone, email)
                )
            else:
                self.conn.execute(
                    "UPDATE mechanics SET full_name = ?, position = ?, phone = ?, email = ? WHERE mechanic_id = ?",
                    (full_name, position, phone, email, mechanic_id)
                )

            self.conn.commit()
            refresh_callback()
            win.destroy()

        ttk.Button(win, text="Сохранить", command=save).pack(fill=tk.X, padx=10, pady=(20, 5))
        ttk.Button(win, text="Отмена", command=win.destroy).pack(fill=tk.X, padx=10, pady=5)

    def _open_unit_sensor_form(self, refresh_callback=None, unit_id=None):
        win = tk.Toplevel(self)
        win.title("Объект мониторинга")
        win.geometry("540x420")
        win.transient(self)
        win.grab_set()

        cursor = self.conn.cursor()

        machines = cursor.execute("SELECT machine_id, name FROM machines ORDER BY machine_id").fetchall()
        mechanics = cursor.execute("""
            SELECT
                m.machine_id,
                me.full_name
            FROM machine_mechanics mm
            JOIN machines m ON mm.machine_id = m.machine_id
            JOIN mechanics me ON mm.mechanic_id = me.mechanic_id
        """).fetchall()

        mechanic_by_machine = {row["machine_id"]: row["full_name"] for row in mechanics}

        unit_data = None
        sensor_data = None

        if unit_id is not None:
            unit_data = cursor.execute("SELECT * FROM units WHERE unit_id = ?", (unit_id,)).fetchone()
            sensor_data = cursor.execute("SELECT * FROM sensors WHERE unit_id = ? LIMIT 1", (unit_id,)).fetchone()

        ttk.Label(win, text="Техника:").pack(anchor=tk.W, padx=10, pady=(10, 2))

        machine_values = [f"{m['machine_id']} — {m['name']}" for m in machines]
        machine_var = tk.StringVar()

        machine_combo = ttk.Combobox(win, textvariable=machine_var, values=machine_values, state="readonly")
        machine_combo.pack(fill=tk.X, padx=10)

        mechanic_label = ttk.Label(win, text="Ответственный механик: -")
        mechanic_label.pack(anchor=tk.W, padx=10, pady=(8, 2))

        ttk.Label(win, text="Тип контролируемого узла:").pack(anchor=tk.W, padx=10, pady=(10, 2))

        unit_type_var = tk.StringVar(value="Двигатель")
        unit_type_combo = ttk.Combobox(
            win,
            textvariable=unit_type_var,
            values=["Двигатель", "Редуктор", "Турбина"],
            state="readonly"
        )
        unit_type_combo.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Наименование узла:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        unit_name_entry = ttk.Entry(win)
        unit_name_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Наименование датчика:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        sensor_name_entry = ttk.Entry(win)
        sensor_name_entry.pack(fill=tk.X, padx=10)

        def get_selected_machine_id():
            value = machine_var.get()
            if not value:
                return None
            return int(value.split("—")[0].strip())

        def on_machine_change(event=None):
            machine_id = get_selected_machine_id()
            if not machine_id:
                mechanic_label.config(text="Ответственный механик: -")
                return

            mechanic_name = mechanic_by_machine.get(machine_id, "не закреплен")
            mechanic_label.config(text=f"Ответственный механик: {mechanic_name}")

        machine_combo.bind("<<ComboboxSelected>>", on_machine_change)

        if unit_data:
            for value in machine_values:
                if value.startswith(str(unit_data["machine_id"])):
                    machine_var.set(value)
                    break

            unit_type_var.set(unit_data["unit_type"] or "Двигатель")
            unit_name_entry.insert(0, unit_data["name"] or "")

            if sensor_data:
                sensor_name_entry.insert(0, sensor_data["name"] or "")

            on_machine_change()

        def save():
            machine_id = get_selected_machine_id()
            unit_type = unit_type_var.get()
            unit_name = unit_name_entry.get().strip() or unit_type
            sensor_name = sensor_name_entry.get().strip() or f"Датчик {unit_type}"

            if not machine_id:
                messagebox.showerror("Ошибка", "Выберите технику.")
                return

            if unit_id is None:
                duplicate = cursor.execute(
                    "SELECT 1 FROM units WHERE machine_id = ? AND unit_type = ?",
                    (machine_id, unit_type)
                ).fetchone()

                if duplicate:
                    messagebox.showerror("Ошибка", "Для выбранной техники уже существует узел такого типа.")
                    return

                cursor.execute(
                    "INSERT INTO units (machine_id, name, unit_type) VALUES (?, ?, ?)",
                    (machine_id, unit_name, unit_type)
                )
                new_unit_id = cursor.lastrowid

                cursor.execute(
                    "INSERT INTO sensors (unit_id, name) VALUES (?, ?)",
                    (new_unit_id, sensor_name)
                )

            else:
                cursor.execute(
                    "UPDATE units SET machine_id = ?, name = ?, unit_type = ? WHERE unit_id = ?",
                    (machine_id, unit_name, unit_type, unit_id)
                )

                existing_sensor = cursor.execute(
                    "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                    (unit_id,)
                ).fetchone()

                if existing_sensor:
                    cursor.execute(
                        "UPDATE sensors SET name = ? WHERE sensor_id = ?",
                        (sensor_name, existing_sensor["sensor_id"])
                    )
                else:
                    cursor.execute(
                        "INSERT INTO sensors (unit_id, name) VALUES (?, ?)",
                        (unit_id, sensor_name)
                    )

            self.conn.commit()

            if refresh_callback:
                refresh_callback()

            self._refresh_all()
            win.destroy()

        ttk.Button(win, text="Сохранить", command=save).pack(fill=tk.X, padx=10, pady=(20, 5))
        ttk.Button(win, text="Отмена", command=win.destroy).pack(fill=tk.X, padx=10, pady=5)

    def _open_assignment_form(self, refresh_callback, assignment_id=None):
        win = tk.Toplevel(self)
        win.title("Закрепление механика")
        win.geometry("540x300")
        win.transient(self)
        win.grab_set()

        cursor = self.conn.cursor()
        machines = cursor.execute("SELECT machine_id, name FROM machines ORDER BY machine_id").fetchall()
        mechanics = cursor.execute("SELECT mechanic_id, full_name FROM mechanics ORDER BY mechanic_id").fetchall()

        assignment = None
        if assignment_id is not None:
            assignment = cursor.execute(
                "SELECT * FROM machine_mechanics WHERE id = ?",
                (assignment_id,)
            ).fetchone()

        ttk.Label(win, text="Техника:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        machine_values = [f"{m['machine_id']} — {m['name']}" for m in machines]
        machine_var = tk.StringVar()
        machine_combo = ttk.Combobox(win, textvariable=machine_var, values=machine_values, state="readonly")
        machine_combo.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Механик:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        mechanic_values = [f"{m['mechanic_id']} — {m['full_name']}" for m in mechanics]
        mechanic_var = tk.StringVar()
        mechanic_combo = ttk.Combobox(win, textvariable=mechanic_var, values=mechanic_values, state="readonly")
        mechanic_combo.pack(fill=tk.X, padx=10)

        if assignment:
            for value in machine_values:
                if value.startswith(str(assignment["machine_id"])):
                    machine_var.set(value)
                    break

            for value in mechanic_values:
                if value.startswith(str(assignment["mechanic_id"])):
                    mechanic_var.set(value)
                    break

        def get_id(value):
            if not value:
                return None
            return int(value.split("—")[0].strip())

        def save():
            machine_id = get_id(machine_var.get())
            mechanic_id = get_id(mechanic_var.get())

            if not machine_id or not mechanic_id:
                messagebox.showerror("Ошибка", "Выберите технику и механика.")
                return

            if assignment_id is None:
                cursor.execute(
                    "INSERT INTO machine_mechanics (machine_id, mechanic_id, assignment_date) VALUES (?, ?, ?)",
                    (machine_id, mechanic_id, datetime.now().isoformat(timespec="seconds"))
                )
            else:
                cursor.execute(
                    "UPDATE machine_mechanics SET machine_id = ?, mechanic_id = ? WHERE id = ?",
                    (machine_id, mechanic_id, assignment_id)
                )

            self.conn.commit()
            refresh_callback()
            self._refresh_all()
            win.destroy()

        ttk.Button(win, text="Сохранить", command=save).pack(fill=tk.X, padx=10, pady=(20, 5))
        ttk.Button(win, text="Отмена", command=win.destroy).pack(fill=tk.X, padx=10, pady=5)

    # ------------------------------------------------------------------
    # ДОБАВЛЕНИЕ ОБЪЕКТА МОНИТОРИНГА
    # ------------------------------------------------------------------

    def show_add_monitoring_object(self):
        self._open_unit_sensor_form(refresh_callback=self._refresh_all)

    # ------------------------------------------------------------------
    # СПРАВОЧНИКИ
    # ------------------------------------------------------------------

    def show_directories_editor(self):
        password = simpledialog.askstring(
            "Доступ к справочникам",
            "Введите пароль администратора:",
            show="*"
        )

        if password != "admin":
            messagebox.showerror("Ошибка", "Неверный пароль. Доступ запрещен.")
            return

        self.clear_center()
        self.current_frame = "directories"

        ttk.Label(
            self.center_panel,
            text="Изменение справочников",
            style="Title.TLabel"
        ).pack(anchor=tk.W, pady=(0, 5))

        notebook = ttk.Notebook(self.center_panel)
        notebook.pack(fill=tk.BOTH, expand=True)

        machines_frame = ttk.Frame(notebook)
        units_frame = ttk.Frame(notebook)
        sensors_frame = ttk.Frame(notebook)
        mechanics_frame = ttk.Frame(notebook)
        assignments_frame = ttk.Frame(notebook)

        notebook.add(machines_frame, text="Техника")
        notebook.add(units_frame, text="Узлы")
        notebook.add(sensors_frame, text="Датчики")
        notebook.add(mechanics_frame, text="Механики")
        notebook.add(assignments_frame, text="Закрепления")

        self._create_machines_editor(machines_frame)
        self._create_units_editor(units_frame)
        self._create_sensors_editor(sensors_frame)
        self._create_mechanics_editor(mechanics_frame)
        self._create_assignments_editor(assignments_frame)

    def _create_simple_tree(self, parent, columns, headings):
        container = ttk.Frame(parent)
        container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        tree = ttk.Treeview(container, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=headings.get(col, col))
            tree.column(col, width=120)

        scroll = ttk.Scrollbar(container, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)

        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        return tree

    def _create_machines_editor(self, parent):
        columns = ("id", "name", "model", "type", "status")
        headings = {
            "id": "ID",
            "name": "Наименование",
            "model": "Модель",
            "type": "Тип",
            "status": "Статус"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())
            rows = self.conn.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["machine_id"],
                    row["name"],
                    row["model"] or "-",
                    row["type"] or "-",
                    row["status"] or "-"
                ))

        def add():
            self._open_machine_form(refresh_callback=refresh)

        def edit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Внимание", "Выберите запись для изменения.")
                return

            values = tree.item(selected[0])["values"]
            self._open_machine_form(refresh_callback=refresh, machine_id=values[0])

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранную технику?"):
                self.conn.execute("DELETE FROM machines WHERE machine_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self._refresh_all()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Изменить", command=edit).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_units_editor(self, parent):
        columns = ("id", "machine", "name", "type")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "name": "Узел",
            "type": "Тип узла"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    u.unit_id,
                    m.name AS machine_name,
                    u.name,
                    u.unit_type
                FROM units u
                JOIN machines m ON u.machine_id = m.machine_id
                ORDER BY u.unit_id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["unit_id"],
                    row["machine_name"],
                    row["name"],
                    row["unit_type"]
                ))

        def add():
            self._open_unit_sensor_form(refresh_callback=refresh)

        def edit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Внимание", "Выберите запись для изменения.")
                return

            values = tree.item(selected[0])["values"]
            self._open_unit_sensor_form(refresh_callback=refresh, unit_id=values[0])

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранный узел?"):
                self.conn.execute("DELETE FROM units WHERE unit_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self._refresh_all()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Изменить", command=edit).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_sensors_editor(self, parent):
        columns = ("id", "machine", "unit", "sensor")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "unit": "Узел",
            "sensor": "Датчик"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    s.sensor_id,
                    s.name AS sensor_name,
                    u.unit_id,
                    u.name AS unit_name,
                    m.name AS machine_name
                FROM sensors s
                JOIN units u ON s.unit_id = u.unit_id
                JOIN machines m ON u.machine_id = m.machine_id
                ORDER BY s.sensor_id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["sensor_id"],
                    row["machine_name"],
                    row["unit_name"],
                    row["sensor_name"]
                ))

        def edit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Внимание", "Выберите запись для изменения.")
                return

            values = tree.item(selected[0])["values"]
            sensor_id = values[0]

            row = self.conn.execute(
                "SELECT unit_id FROM sensors WHERE sensor_id = ?",
                (sensor_id,)
            ).fetchone()

            if row:
                self._open_unit_sensor_form(refresh_callback=refresh, unit_id=row["unit_id"])

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранный датчик?"):
                self.conn.execute("DELETE FROM sensors WHERE sensor_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self._refresh_all()

        ttk.Button(btn_frame, text="Изменить", command=edit).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_mechanics_editor(self, parent):
        columns = ("id", "full_name", "position", "phone", "email")
        headings = {
            "id": "ID",
            "full_name": "ФИО",
            "position": "Должность",
            "phone": "Телефон",
            "email": "E-mail"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())
            rows = self.conn.execute("SELECT * FROM mechanics ORDER BY mechanic_id").fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["mechanic_id"],
                    row["full_name"],
                    row["position"] or "-",
                    row["phone"] or "-",
                    row["email"] or "-"
                ))

        def add():
            self._open_mechanic_form(refresh_callback=refresh)

        def edit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Внимание", "Выберите запись для изменения.")
                return

            values = tree.item(selected[0])["values"]
            self._open_mechanic_form(refresh_callback=refresh, mechanic_id=values[0])

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранного механика?"):
                self.conn.execute("DELETE FROM mechanics WHERE mechanic_id = ?", (values[0],))
                self.conn.commit()
                refresh()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Изменить", command=edit).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_assignments_editor(self, parent):
        columns = ("id", "machine", "mechanic", "date")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "mechanic": "Механик",
            "date": "Дата закрепления"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    mm.id,
                    m.name AS machine_name,
                    me.full_name AS mechanic_name,
                    mm.assignment_date
                FROM machine_mechanics mm
                JOIN machines m ON mm.machine_id = m.machine_id
                JOIN mechanics me ON mm.mechanic_id = me.mechanic_id
                ORDER BY mm.id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["id"],
                    row["machine_name"],
                    row["mechanic_name"],
                    row["assignment_date"] or "-"
                ))

        def add():
            self._open_assignment_form(refresh_callback=refresh)

        def edit():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning("Внимание", "Выберите запись для изменения.")
                return

            values = tree.item(selected[0])["values"]
            self._open_assignment_form(refresh_callback=refresh, assignment_id=values[0])

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить закрепление?"):
                self.conn.execute("DELETE FROM machine_mechanics WHERE id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self._refresh_all()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Изменить", command=edit).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    # ------------------------------------------------------------------
    # ПРОСМОТР БАЗЫ ДАННЫХ
    # ------------------------------------------------------------------

    def show_database_view(self):
        self.clear_center()
        self.current_frame = "database"

        ttk.Label(
            self.center_panel,
            text="Просмотр базы данных",
            style="Title.TLabel"
        ).pack(anchor=tk.W, pady=(0, 5))

        top_frame = ttk.LabelFrame(
            self.center_panel,
            text="Основная таблица техники",
            style="Block.TLabelframe"
        )
        top_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        columns = ("id", "name", "model", "type", "status")
        self.db_machines_tree = ttk.Treeview(top_frame, columns=columns, show="headings", height=8)

        headings = {
            "id": "ID",
            "name": "Наименование",
            "model": "Модель",
            "type": "Тип",
            "status": "Статус"
        }

        for col in columns:
            self.db_machines_tree.heading(col, text=headings[col])
            self.db_machines_tree.column(col, width=120)

        self.db_machines_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.db_machines_tree.bind("<<TreeviewSelect>>", self.on_db_machine_select)

        control_frame = ttk.Frame(self.center_panel)
        control_frame.pack(fill=tk.X, pady=5)

        ttk.Label(control_frame, text="Режим просмотра:").pack(side=tk.LEFT, padx=5)

        self.view_mode_var = tk.StringVar(value="history")
        modes = [
            ("История измерений и анализа", "history"),
            ("График вибросигнала", "signal_graph"),
            ("График истории состояния", "state_graph")
        ]

        for text, value in modes:
            ttk.Radiobutton(
                control_frame,
                text=text,
                variable=self.view_mode_var,
                value=value,
                command=self.update_db_view
            ).pack(side=tk.LEFT, padx=5)

        ttk.Label(control_frame, text="Фильтр по типу узла:").pack(side=tk.LEFT, padx=(15, 5))

        self.filter_var = tk.StringVar(value="Все")
        filter_combo = ttk.Combobox(
            control_frame,
            textvariable=self.filter_var,
            values=["Все", "Двигатель", "Редуктор", "Турбина"],
            state="readonly",
            width=15
        )
        filter_combo.pack(side=tk.LEFT)
        filter_combo.bind("<<ComboboxSelected>>", lambda e: self.update_db_view())

        ttk.Label(control_frame, text="Дата с:").pack(side=tk.LEFT, padx=(15, 5))
        self.date_from_var = tk.StringVar()
        date_from_entry = ttk.Entry(control_frame, textvariable=self.date_from_var, width=12)
        date_from_entry.pack(side=tk.LEFT)

        ttk.Label(control_frame, text="по:").pack(side=tk.LEFT, padx=(8, 5))
        self.date_to_var = tk.StringVar()
        date_to_entry = ttk.Entry(control_frame, textvariable=self.date_to_var, width=12)
        date_to_entry.pack(side=tk.LEFT)

        ttk.Button(control_frame, text="Применить", command=self.update_db_view).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="Сбросить даты", command=self._reset_date_filter).pack(side=tk.LEFT, padx=5)

        self.db_bottom_frame = ttk.LabelFrame(
            self.center_panel,
            text="Связанные данные",
            style="Block.TLabelframe"
        )
        self.db_bottom_frame.pack(fill=tk.BOTH, expand=True)

        self._fill_db_machines()

    def _fill_db_machines(self):
        self.db_machines_tree.delete(*self.db_machines_tree.get_children())

        rows = self.conn.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()
        for row in rows:
            self.db_machines_tree.insert("", tk.END, values=(
                row["machine_id"],
                row["name"],
                row["model"] or "-",
                row["type"] or "-",
                row["status"] or "-"
            ))

    def on_db_machine_select(self, event):
        selected = self.db_machines_tree.selection()
        if not selected:
            return

        values = self.db_machines_tree.item(selected[0])["values"]
        self.current_machine_id = values[0]
        self.update_db_view()

    def update_db_view(self):
        if self.current_frame != "database":
            return

        for widget in self.db_bottom_frame.winfo_children():
            widget.destroy()

        if not self.current_machine_id:
            ttk.Label(self.db_bottom_frame, text="Выберите технику в верхней таблице.").pack(pady=30)
            return

        mode = self.view_mode_var.get()

        if mode == "history":
            self._show_history_view()
        elif mode == "signal_graph":
            self._show_signal_graph()
        elif mode == "state_graph":
            self._show_state_graph()

    def _show_history_view(self):
        filter_type = self.filter_var.get()

        date_from, date_to = self._get_date_filter_values()
        if date_from is None and date_to is None:
            return

        columns = ("time", "unit", "sensor", "state", "confidence", "recommendation")
        tree = ttk.Treeview(self.db_bottom_frame, columns=columns, show="headings", height=15)

        tree.heading("time", text="Дата/время анализа")
        tree.heading("unit", text="Тип узла")
        tree.heading("sensor", text="Датчик")
        tree.heading("state", text="Состояние")
        tree.heading("confidence", text="Уверенность")
        tree.heading("recommendation", text="Рекомендация")

        tree.column("time", width=160)
        tree.column("unit", width=120)
        tree.column("sensor", width=120)
        tree.column("state", width=120)
        tree.column("confidence", width=100)
        tree.column("recommendation", width=300)

        tree.tag_configure("normal", background="#FFFFFF")
        tree.tag_configure("wear", background="#FFF4CC")
        tree.tag_configure("fault", background="#FFD6D6")

        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        cursor = self.conn.cursor()
        units = cursor.execute(
            "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
            (self.current_machine_id,)
        ).fetchall()

        has_rows = False

        for unit in units:
            if filter_type != "Все" and unit["unit_type"] != filter_type:
                continue

            sensor = cursor.execute(
                "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                (unit["unit_id"],)
            ).fetchone()

            if not sensor:
                continue

            history = get_analysis_history(self.conn, sensor["sensor_id"])

            for item in history:
                if not self._date_in_range(item["analysis_time"]):
                    continue

                has_rows = True

                state_name = item["state_name_ru"]
                tag = self._get_state_tag(state_name)

                recommendation = item["recommendation"] or "-"
                if len(recommendation) > 60:
                    recommendation = recommendation[:60] + "..."

                tree.insert("", tk.END, values=(
                    item["analysis_time"],
                    unit["unit_type"],
                    sensor["name"],
                    state_name,
                    f"{item['average_probability']:.2f}",
                    recommendation
                ), tags=(tag,))

        if not has_rows:
            tree.insert("", tk.END, values=(
                "-",
                "-",
                "-",
                "-",
                "-",
                "Нет данных за выбранный период"
            ))

    def _show_signal_graph(self):
        filter_type = self.filter_var.get()

        date_from, date_to = self._get_date_filter_values()
        if date_from is None and date_to is None:
            return

        cursor = self.conn.cursor()

        sql = """
            SELECT
                s.sensor_id,
                s.name AS sensor_name,
                u.name AS unit_name,
                u.unit_type
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            WHERE u.machine_id = ?
        """

        params = [self.current_machine_id]

        if filter_type != "Все":
            sql += " AND u.unit_type = ?"
            params.append(filter_type)

        sql += " ORDER BY u.unit_id, s.sensor_id"

        sensors = cursor.execute(sql, params).fetchall()

        if not sensors:
            ttk.Label(
                self.db_bottom_frame,
                text="Для выбранной техники и выбранного типа узла нет датчиков."
            ).pack(pady=30)
            return

        fig, ax = plt.subplots(figsize=(10, 4))
        has_data = False

        for sensor in sensors:
            readings_sql = """
                SELECT timestamp, value
                FROM sensor_readings
                WHERE sensor_id = ?
            """

            reading_params = [sensor["sensor_id"]]

            if date_from:
                readings_sql += " AND substr(timestamp, 1, 10) >= ?"
                reading_params.append(date_from)

            if date_to:
                readings_sql += " AND substr(timestamp, 1, 10) <= ?"
                reading_params.append(date_to)

            readings_sql += " ORDER BY timestamp"

            rows = cursor.execute(readings_sql, reading_params).fetchall()

            if not rows:
                continue

            has_data = True
            values = [row["value"] for row in rows]
            values = values[-500:] if len(values) > 500 else values

            label = f"{sensor['unit_name']} / {sensor['unit_type']} / {sensor['sensor_name']}"
            ax.plot(values, linewidth=0.8, label=label)

        if not has_data:
            ttk.Label(
                self.db_bottom_frame,
                text="Нет вибрационных измерений за выбранный период."
            ).pack(pady=30)
            return

        if filter_type == "Все":
            title = "График вибрационного сигнала по всем узлам"
        else:
            title = f"График вибрационного сигнала: {filter_type}"

        ax.set_title(title)
        ax.set_xlabel("Номер отсчета")
        ax.set_ylabel("Амплитуда")
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.db_bottom_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def _show_state_graph(self):
        filter_type = self.filter_var.get()

        date_from, date_to = self._get_date_filter_values()
        if date_from is None and date_to is None:
            return

        cursor = self.conn.cursor()

        units_sql = """
            SELECT *
            FROM units
            WHERE machine_id = ?
        """

        params = [self.current_machine_id]

        if filter_type != "Все":
            units_sql += " AND unit_type = ?"
            params.append(filter_type)

        units_sql += " ORDER BY unit_id"

        units = cursor.execute(units_sql, params).fetchall()

        if not units:
            ttk.Label(
                self.db_bottom_frame,
                text="Нет узлов для построения графика состояния."
            ).pack(pady=30)
            return

        fig, ax = plt.subplots(figsize=(10, 4))
        has_data = False

        for unit in units:
            sensor = cursor.execute(
                "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                (unit["unit_id"],)
            ).fetchone()

            if not sensor:
                continue

            history = get_analysis_history(self.conn, sensor["sensor_id"])

            history = [
                h for h in history
                if self._date_in_range(h["analysis_time"])
            ]

            if not history:
                continue

            has_data = True
            history.sort(key=lambda x: x["analysis_time"])

            times = [h["analysis_time"][11:16] for h in history]
            levels = [self.STATE_LEVELS.get(h["dominant_state"], 0) for h in history]

            ax.plot(
                times,
                levels,
                marker="o",
                label=f"{unit['name']} ({unit['unit_type']})"
            )

        if not has_data:
            ttk.Label(
                self.db_bottom_frame,
                text="Нет результатов анализа за выбранный период."
            ).pack(pady=30)
            return

        if filter_type == "Все":
            title = "График истории состояния узлов"
        else:
            title = f"График истории состояния: {filter_type}"

        ax.set_title(title)
        ax.set_xlabel("Время")
        ax.set_ylabel("Состояние")
        ax.set_yticks([0, 1, 2])
        ax.set_yticklabels(["Норма", "Износ", "Сильный износ"])
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.xticks(rotation=45)
        plt.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.db_bottom_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # ------------------------------------------------------------------
    # ЗАГРУЗКА CSV
    # ------------------------------------------------------------------

    def load_csv_data(self):
        file_path = filedialog.askopenfilename(
            title="Выберите CSV-файл",
            filetypes=[("CSV files", "*.csv")]
        )

        if not file_path:
            return

        try:
            df = load_sensor_csv(file_path)
            cursor = self.conn.cursor()

            sensor_ids = df["sensor_id"].unique()
            unknown_sensors = []

            for sid in sensor_ids:
                exists = cursor.execute(
                    "SELECT 1 FROM sensors WHERE sensor_id = ?",
                    (int(sid),)
                ).fetchone()

                if not exists:
                    unknown_sensors.append(str(sid))

            if unknown_sensors:
                messagebox.showwarning(
                    "Предупреждение",
                    "Неизвестные датчики: " + ", ".join(unknown_sensors)
                )
                df = df[~df["sensor_id"].isin([int(s) for s in unknown_sensors])]

            if df.empty:
                messagebox.showerror("Ошибка", "Нет данных для загрузки.")
                return

            inserted = 0

            for _, row in df.iterrows():
                cursor.execute(
                    "INSERT INTO sensor_readings (sensor_id, timestamp, value) VALUES (?, ?, ?)",
                    (int(row["sensor_id"]), row["timestamp"].isoformat(), float(row["value"]))
                )
                inserted += 1

            self.conn.commit()

            messagebox.showinfo("Готово", f"Загружено записей: {inserted}")
            self._refresh_all()

        except Exception as e:
            messagebox.showerror("Ошибка загрузки", str(e))

    # ------------------------------------------------------------------
    # ОПОВЕЩЕНИЯ
    # ------------------------------------------------------------------

    def refresh_notifications(self):
        self.notifications_listbox.delete(0, tk.END)

        rows = self.conn.execute("""
            SELECT notification_time, message
            FROM dispatcher_notifications
            ORDER BY notification_id DESC
            LIMIT 30
        """).fetchall()

        if not rows:
            self.notifications_listbox.insert(tk.END, "Новых оповещений нет")
            return

        for row in rows:
            time_str = row["notification_time"][11:16] if row["notification_time"] else ""
            message = row["message"] or ""

            if len(message) > 70:
                message = message[:70] + "..."

            self.notifications_listbox.insert(tk.END, f"{time_str}: {message}")

    # ------------------------------------------------------------------
    # ЗАКРЫТИЕ
    # ------------------------------------------------------------------

    def on_closing(self):
        self.analysis_running = False

        if self.analysis_job is not None:
            try:
                self.after_cancel(self.analysis_job)
            except Exception:
                pass

        self.conn.close()
        self.destroy()


if __name__ == "__main__":
    app = MonitoringApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()