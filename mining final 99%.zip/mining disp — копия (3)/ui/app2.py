import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from datetime import datetime, timedelta

import matplotlib.pyplot as plt
import numpy as np

from database.db import get_connection
from services.data_loader import load_sensor_csv
from models.ml_model import load_model_for_sensor
from services.analysis_service import (
    analyze_signal_segment,
    get_sensor_values,
    get_latest_sensor_verdict,
    get_analysis_history,
)


class MonitoringApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Диспетчерский мониторинг состояния узлов горной техники")
        self.geometry("1550x900")
        self.minsize(1380, 780)

        self.stream_running = False
        self.stream_after_id = None
        self.stream_sensor_id = None
        self.stream_model = None
        self.stream_packet_index = 0
        self.stream_packet_size = 32
        self.stream_interval_ms = 1000
        self.stream_start_time = None
        self.stream_rng = np.random.default_rng(2026)
        self.streams = {}
        self.stream_mode = None

        self.active_sensor_id = None

        self._configure_styles()
        self._build_ui()
        self.refresh_data()

    def _configure_styles(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("Main.TButton", font=("Arial", 10))
        style.configure("Panel.TLabelframe", padding=10)
        style.configure("Panel.TLabelframe.Label", font=("Arial", 11, "bold"))

    def _build_ui(self):
        self.configure(bg="#eef2f5")

        content_frame = ttk.Frame(self, padding=(10, 10, 10, 10))
        content_frame.pack(fill="both", expand=True)

        left_frame = ttk.LabelFrame(
            content_frame,
            text="Контролируемая техника и датчики",
            style="Panel.TLabelframe"
        )
        left_frame.pack(side="left", fill="both", expand=False, padx=(0, 8))
        left_frame.configure(width=470)

        self.sensor_tree = ttk.Treeview(
            left_frame,
            columns=("sensor_id", "machine", "unit", "sensor_name"),
            show="headings",
            height=27
        )
        self.sensor_tree.heading("sensor_id", text="ID")
        self.sensor_tree.heading("machine", text="Техника")
        self.sensor_tree.heading("unit", text="Узел")
        self.sensor_tree.heading("sensor_name", text="Датчик")

        self.sensor_tree.column("sensor_id", width=70, anchor="center")
        self.sensor_tree.column("machine", width=190)
        self.sensor_tree.column("unit", width=120)
        self.sensor_tree.column("sensor_name", width=120)

        sensor_scroll = ttk.Scrollbar(left_frame, orient="vertical", command=self.sensor_tree.yview)
        self.sensor_tree.configure(yscrollcommand=sensor_scroll.set)

        self.sensor_tree.pack(side="top", fill="both", expand=True)
        sensor_scroll.pack(side="right", fill="y")

        self.sensor_tree.tag_configure("normal", background="#ffffff")
        self.sensor_tree.tag_configure("wear", background="#fff4d6")
        self.sensor_tree.tag_configure("fault", background="#fde0dd")
        self.sensor_tree.tag_configure("no_data", background="#f2f2f2")

        left_buttons = ttk.Frame(left_frame)
        left_buttons.pack(fill="x", pady=(10, 0))

        ttk.Button(
            left_buttons,
            text="Добавить объект мониторинга",
            command=self.open_add_equipment_window,
            style="Main.TButton"
        ).pack(fill="x", pady=3)

        ttk.Button(
            left_buttons,
            text="Обновить список",
            command=self.refresh_data,
            style="Main.TButton"
        ).pack(fill="x", pady=3)

        self.sensor_tree.bind("<<TreeviewSelect>>", self.on_sensor_select)
        self.sensor_tree.bind("<Button-1>", self.on_tree_click, add="+")

        center_frame = ttk.Frame(content_frame)
        center_frame.pack(side="left", fill="both", expand=True, padx=8)

        status_frame = ttk.LabelFrame(
            center_frame,
            text="Текущее состояние узла",
            style="Panel.TLabelframe"
        )
        status_frame.pack(fill="x", pady=(0, 10))

        self.status_card = tk.Frame(status_frame, bg="#d9d9d9", padx=24, pady=24)
        self.status_card.pack(fill="x")

        self.status_title = tk.Label(
            self.status_card,
            text="Нет данных",
            font=("Arial", 26, "bold"),
            bg="#d9d9d9",
            fg="black"
        )
        self.status_title.pack(anchor="w")

        self.status_subtitle = tk.Label(
            self.status_card,
            text="Выберите датчик слева и запустите приём данных",
            font=("Arial", 12),
            bg="#d9d9d9",
            fg="black",
            justify="left"
        )
        self.status_subtitle.pack(anchor="w", pady=(10, 0))

        stream_frame = ttk.LabelFrame(
            center_frame,
            text="Приём данных с датчика",
            style="Panel.TLabelframe"
        )
        stream_frame.pack(fill="x", pady=(0, 10))

        self.stream_status_label = ttk.Label(
            stream_frame,
            text="Приём данных остановлен",
            font=("Arial", 10, "bold")
        )
        self.stream_status_label.pack(anchor="w", pady=(0, 6))

        stream_buttons = ttk.Frame(stream_frame)
        stream_buttons.pack(fill="x")

        ttk.Button(
            stream_buttons,
            text="Запустить выбранный объект",
            command=self.start_data_stream,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        ttk.Button(
            stream_buttons,
            text="Запустить все объекты",
            command=self.start_all_data_streams,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        ttk.Button(
            stream_buttons,
            text="Остановить мониторинг",
            command=self.stop_data_stream,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        ttk.Button(
            stream_buttons,
            text="Загрузить архивные данные",
            command=self.load_csv,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        ttk.Button(
            stream_buttons,
            text="Показать график",
            command=self.plot_selected_sensor,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        ttk.Button(
            stream_buttons,
            text="История анализов",
            command=self.show_analysis_history_window,
            style="Main.TButton"
        ).pack(side="left", padx=4)

        info_frame = ttk.LabelFrame(
            center_frame,
            text="Подробная информация",
            style="Panel.TLabelframe"
        )
        info_frame.pack(fill="both", expand=True, pady=(0, 10))

        self.info_text = tk.Text(
            info_frame,
            wrap="word",
            height=18,
            font=("Arial", 11),
            padx=10,
            pady=10
        )
        self.info_text.pack(fill="both", expand=True)

        right_frame = ttk.Frame(content_frame)
        right_frame.pack(side="right", fill="both", expand=False, padx=(8, 0))
        right_frame.configure(width=430)

        summary_frame = ttk.LabelFrame(
            right_frame,
            text="Карточка объекта мониторинга",
            style="Panel.TLabelframe"
        )
        summary_frame.pack(fill="both", expand=True, pady=(0, 10))

        self.summary_text = tk.Text(
            summary_frame,
            wrap="word",
            height=18,
            font=("Arial", 11),
            padx=10,
            pady=10
        )
        self.summary_text.pack(fill="both", expand=True)

        dispatcher_alerts_frame = ttk.LabelFrame(
            right_frame,
            text="Оповещения диспетчеру",
            style="Panel.TLabelframe"
        )
        dispatcher_alerts_frame.pack(fill="both", expand=True)

        self.alerts_tree = ttk.Treeview(
            dispatcher_alerts_frame,
            columns=("time", "level", "message"),
            show="headings",
            height=11
        )
        self.alerts_tree.heading("time", text="Время")
        self.alerts_tree.heading("level", text="Уровень")
        self.alerts_tree.heading("message", text="Оповещение")

        self.alerts_tree.column("time", width=145, anchor="center")
        self.alerts_tree.column("level", width=105, anchor="center")
        self.alerts_tree.column("message", width=470)

        alerts_scroll = ttk.Scrollbar(
            dispatcher_alerts_frame,
            orient="vertical",
            command=self.alerts_tree.yview
        )
        self.alerts_tree.configure(yscrollcommand=alerts_scroll.set)

        self.alerts_tree.pack(side="left", fill="both", expand=True)
        alerts_scroll.pack(side="right", fill="y")

        log_frame = ttk.LabelFrame(
            self,
            text="Журнал работы программного средства",
            style="Panel.TLabelframe"
        )
        log_frame.pack(fill="x", padx=10, pady=(0, 10))

        self.log_text = tk.Text(
            log_frame,
            height=8,
            font=("Consolas", 10),
            padx=8,
            pady=8
        )
        self.log_text.pack(fill="both", expand=True)

    def log(self, message: str):
        now = datetime.now().strftime("%H:%M:%S")
        self.log_text.insert("end", f"[{now}] {message}\n")
        self.log_text.see("end")

    def refresh_data(self):
        self.load_sensors()
        self.update_ui_for_selected_sensor()

    def get_selected_sensor_id(self):
        return self.active_sensor_id

    def get_state_ru(self, state: str) -> str:
        return {
            "normal": "Норма",
            "wear": "Износ",
            "fault": "Сильный износ"
        }.get(state, state)

    def get_state_explanation(self, state: str) -> str:
        mapping = {
            "normal": "Показатели вибрации находятся в допустимых пределах. Срочные действия не требуются.",
            "wear": "Выявлены признаки износа. Нужно запланировать осмотр, чтобы предотвратить серьёзную поломку.",
            "fault": "Обнаружен сильный износ. Требуется срочное вмешательство для предотвращения отказа техники."
        }
        return mapping.get(state, "Требуется дополнительная проверка состояния узла.")

    def get_state_card_colors(self, state: str):
        mapping = {
            "normal": ("#dff3e2", "#1f7a1f"),
            "wear": ("#fff4d6", "#b8860b"),
            "fault": ("#fde0dd", "#b22222"),
        }
        return mapping.get(state, ("#d9d9d9", "black"))


    def load_sensors(self):
        previous_active = self.active_sensor_id

        for item in self.sensor_tree.get_children():
            self.sensor_tree.delete(item)

        conn = get_connection()
        rows = conn.execute(
            """
            SELECT
                s.sensor_id AS sensor_id,
                m.name AS machine_name,
                u.name AS unit_name,
                s.name AS sensor_name,

                (
                    SELECT ar.predicted_state
                    FROM analysis_results ar
                    WHERE ar.sensor_id = s.sensor_id
                    ORDER BY ar.result_id DESC
                    LIMIT 1
                ) AS latest_state

            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            JOIN machines m ON u.machine_id = m.machine_id
            ORDER BY m.name, u.name, s.sensor_id
            """
        ).fetchall()
        conn.close()

        item_to_select = None

        for row in rows:
            latest_state = row["latest_state"] or "no_data"

            if latest_state not in ("normal", "wear", "fault"):
                latest_state = "no_data"

            item_id = self.sensor_tree.insert(
                "",
                "end",
                values=(
                    row["sensor_id"],
                    row["machine_name"],
                    row["unit_name"],
                    row["sensor_name"]
                ),
                tags=(latest_state,)
            )

            if previous_active is not None and int(row["sensor_id"]) == int(previous_active):
                item_to_select = item_id

        if item_to_select is not None:
            self.sensor_tree.selection_set(item_to_select)
            self.sensor_tree.focus(item_to_select)

    def get_machines_for_combobox(self):
        conn = get_connection()
        rows = conn.execute(
            """
            SELECT machine_id, name, model, type, status
            FROM machines
            ORDER BY name
            """
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_all_sensor_ids(self):
        conn = get_connection()
        rows = conn.execute(
            """
            SELECT sensor_id
            FROM sensors
            ORDER BY sensor_id
            """
        ).fetchall()
        conn.close()
        return [int(row["sensor_id"]) for row in rows]


    def get_mechanic_by_machine_id(self, machine_id: int):
        conn = get_connection()
        row = conn.execute(
            """
            SELECT
                me.mechanic_id,
                me.full_name,
                me.position,
                me.phone,
                me.email
            FROM machine_mechanics mm
            JOIN mechanics me ON me.mechanic_id = mm.mechanic_id
            WHERE mm.machine_id = ?
            ORDER BY mm.id DESC
            LIMIT 1
            """,
            (machine_id,)
        ).fetchone()
        conn.close()
        return dict(row) if row else None

    def get_sensor_context(self, sensor_id: int):
        conn = get_connection()
        row = conn.execute(
            """
            SELECT
                s.sensor_id,
                s.name AS sensor_name,
                u.unit_id,
                u.name AS unit_name,
                u.unit_type,
                m.machine_id,
                m.name AS machine_name,
                m.model AS machine_model
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            JOIN machines m ON u.machine_id = m.machine_id
            WHERE s.sensor_id = ?
            """,
            (sensor_id,)
        ).fetchone()
        conn.close()
        return dict(row) if row else None

    def get_responsible_mechanic(self, sensor_id: int):
        context = self.get_sensor_context(sensor_id)
        if not context:
            return None
        return self.get_mechanic_by_machine_id(context["machine_id"])

    def get_dispatcher_notifications_for_sensor(self, sensor_id: int, limit: int = 10):
        conn = get_connection()
        rows = conn.execute(
            """
            SELECT
                dn.notification_id,
                dn.notification_time,
                dn.status,
                dn.message,
                a.alert_level
            FROM dispatcher_notifications dn
            JOIN alerts a ON dn.alert_id = a.alert_id
            WHERE dn.sensor_id = ?
            ORDER BY dn.notification_id DESC
            LIMIT ?
            """,
            (sensor_id, limit)
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def update_status_card(self, verdict):
        if verdict is None:
            bg = "#d9d9d9"
            fg = "black"
            self.status_card.configure(bg=bg)
            self.status_title.configure(text="Нет результатов анализа", bg=bg, fg=fg)
            self.status_subtitle.configure(
                text="Выберите датчик слева и запустите приём данных",
                bg=bg,
                fg=fg
            )
            return

        state = verdict["dominant_state"]
        bg, fg = self.get_state_card_colors(state)

        self.status_card.configure(bg=bg)
        self.status_title.configure(
            text=f"Состояние: {self.get_state_ru(state)}",
            bg=bg,
            fg=fg
        )
        self.status_subtitle.configure(
            text=f"{self.get_state_explanation(state)}\nПоследний анализ: {verdict['analysis_time']}",
            bg=bg,
            fg=fg,
            justify="left"
        )

    def update_dispatcher_alerts_table(self, sensor_id: int | None):
        for item in self.alerts_tree.get_children():
            self.alerts_tree.delete(item)

        if sensor_id is None:
            return

        notifications = self.get_dispatcher_notifications_for_sensor(sensor_id)

        for notification in notifications:
            level_ru = {
                "warning": "Износ",
                "critical": "Критично"
            }.get(notification.get("alert_level"), notification.get("alert_level", "-"))

            self.alerts_tree.insert(
                "",
                "end",
                values=(
                    notification["notification_time"],
                    level_ru,
                    notification["message"]
                )
            )

    def update_ui_for_selected_sensor(self):
        self.info_text.delete("1.0", "end")
        self.summary_text.delete("1.0", "end")
        self.update_dispatcher_alerts_table(None)

        sensor_id = self.active_sensor_id
        if sensor_id is None:
            self.update_status_card(None)
            self.info_text.insert(
                "end",
                "Выберите датчик слева, чтобы просмотреть результат мониторинга."
            )
            self.summary_text.insert(
                "end",
                "После выбора датчика здесь будет показана карточка техники и ответственного механика."
            )
            return

        context = self.get_sensor_context(sensor_id)

        conn = get_connection()
        verdict = get_latest_sensor_verdict(conn, sensor_id)
        conn.close()

        mechanic = self.get_responsible_mechanic(sensor_id)

        self.update_status_card(verdict)
        self.update_dispatcher_alerts_table(sensor_id)

        if context:
            self.info_text.insert("end", "СВЕДЕНИЯ ОБ ОБЪЕКТЕ МОНИТОРИНГА\n")
            self.info_text.insert("end", "=" * 60 + "\n")
            self.info_text.insert("end", f"Техника: {context['machine_name']}\n")
            self.info_text.insert("end", f"Модель техники: {context.get('machine_model') or '-'}\n")
            self.info_text.insert("end", f"Узел: {context['unit_name']}\n")
            self.info_text.insert("end", f"Тип узла: {context['unit_type']}\n")
            self.info_text.insert("end", f"Датчик: {context['sensor_name']} (ID {context['sensor_id']})\n\n")

        if verdict is None:
            self.info_text.insert("end", "РЕЗУЛЬТАТ АНАЛИЗА\n")
            self.info_text.insert("end", "=" * 60 + "\n")
            self.info_text.insert("end", "Для выбранного датчика пока нет результатов анализа.\n")
            self.info_text.insert("end", "Запустите приём данных или загрузите архивный CSV-файл.\n")
        else:
            state = verdict["dominant_state"]
            self.info_text.insert("end", "РЕЗУЛЬТАТ ПОСЛЕДНЕГО АНАЛИЗА\n")
            self.info_text.insert("end", "=" * 60 + "\n")
            self.info_text.insert("end", f"Состояние узла: {self.get_state_ru(state)}\n")
            self.info_text.insert("end", f"Время анализа: {verdict['analysis_time']}\n")
            self.info_text.insert("end", f"Уверенность модели: {verdict['confidence_text']}\n")
            self.info_text.insert("end", f"Числовая оценка: {verdict['average_probability']:.2f}\n")
            self.info_text.insert("end", f"Распределение по окнам: {verdict['counts']}\n\n")

            self.info_text.insert("end", "РЕКОМЕНДАЦИЯ\n")
            self.info_text.insert("end", "=" * 60 + "\n")
            self.info_text.insert("end", f"{verdict['recommendation']}\n")

            if state == "fault":
                self.info_text.insert("end", "\nДИСПЕТЧЕРСКОЕ ДЕЙСТВИЕ\n")
                self.info_text.insert("end", "=" * 60 + "\n")
                self.info_text.insert(
                    "end",
                    "Необходимо связаться с ответственным механиком и передать информацию о критическом состоянии узла.\n"
                )

        self.summary_text.insert("end", "КАРТОЧКА ОБЪЕКТА\n")
        self.summary_text.insert("end", "=" * 40 + "\n\n")

        if context:
            self.summary_text.insert("end", f"Техника: {context['machine_name']}\n")
            self.summary_text.insert("end", f"Узел: {context['unit_name']}\n")
            self.summary_text.insert("end", f"Тип узла: {context['unit_type']}\n")
            self.summary_text.insert("end", f"Датчик: {context['sensor_name']}\n\n")

        self.summary_text.insert("end", "ОТВЕТСТВЕННЫЙ МЕХАНИК\n")
        self.summary_text.insert("end", "-" * 40 + "\n")
        if mechanic:
            self.summary_text.insert("end", f"ФИО: {mechanic.get('full_name', '-')}\n")
            self.summary_text.insert("end", f"Должность: {mechanic.get('position', '-')}\n")
            self.summary_text.insert("end", f"Телефон: {mechanic.get('phone', '-')}\n")
            self.summary_text.insert("end", f"Email: {mechanic.get('email', '-')}\n\n")
        else:
            self.summary_text.insert("end", "Не назначен\n\n")

        self.summary_text.insert("end", "СВОДКА ДЛЯ ДИСПЕТЧЕРА\n")
        self.summary_text.insert("end", "-" * 40 + "\n")
        if verdict:
            self.summary_text.insert("end", f"Текущий статус: {self.get_state_ru(verdict['dominant_state'])}\n")
            self.summary_text.insert("end", f"Уверенность: {verdict['confidence_text']}\n")
            self.summary_text.insert("end", f"Оценка: {verdict['average_probability']:.2f}\n\n")
            self.summary_text.insert("end", f"Рекомендация: {verdict['recommendation']}\n")
        else:
            self.summary_text.insert("end", "Результат анализа отсутствует.\n")


    def generate_stream_packet(self, packet_index: int, packet_size: int, rng=None, sensor_id: int | None = None):
        """
        Генерирует пакет числовых измерений вибрации.

        Важно: внутри пакета нет метки "норма", "износ" или "сильный износ".
        В БД сохраняются только sensor_id, timestamp и value.
        Изменение состояния возникает за счёт изменения формы сигнала:
        растёт амплитуда, шум и появляются резкие выбросы.
        """
        rng = rng or self.stream_rng
        offset = (sensor_id or 0) * 17
        t = np.arange(packet_index * packet_size, (packet_index + 1) * packet_size) + offset

        base = 0.25 * np.sin(0.12 * t) + 0.08 * np.sin(0.42 * t)
        noise = rng.normal(0, 0.035, size=packet_size)

        if packet_index < 12:
            signal = base + noise
        elif packet_index < 24:
            signal = base * 1.9 + noise * 2.0 + 0.12 * np.sin(0.75 * t)
        else:
            signal = base * 3.4 + noise * 3.0 + 0.20 * np.sin(0.95 * t)
            if packet_index % 2 == 0:
                spike_count = max(2, packet_size // 12)
                spike_idx = rng.choice(
                    np.arange(packet_size),
                    size=spike_count,
                    replace=False
                )
                signal[spike_idx] += rng.uniform(1.0, 2.2, size=spike_count)

        return signal.tolist()


    def start_data_stream(self):
        sensor_id = self.get_selected_sensor_id()
        if sensor_id is None:
            messagebox.showwarning("Внимание", "Сначала выберите датчик слева.")
            return

        self.start_stream_for_sensors([sensor_id], mode="selected")


    def start_all_data_streams(self):
        sensor_ids = self.get_all_sensor_ids()
        if not sensor_ids:
            messagebox.showwarning("Внимание", "В системе нет датчиков для мониторинга.")
            return

        self.start_stream_for_sensors(sensor_ids, mode="all")

    def start_stream_for_sensors(self, sensor_ids: list[int], mode: str):
        if self.stream_running:
            messagebox.showinfo("Мониторинг", "Мониторинг уже запущен. Сначала остановите текущий приём данных.")
            return

        try:
            conn = get_connection()
            streams = {}

            for sensor_id in sensor_ids:
                streams[sensor_id] = {
                    "model": load_model_for_sensor(conn, sensor_id),
                    "packet_index": 0,
                    "start_time": datetime.now(),
                    "rng": np.random.default_rng(2026 + int(sensor_id) * 101),
                }

            conn.close()

            self.streams = streams
            self.stream_mode = mode
            self.stream_running = True

            if mode == "all":
                self.stream_status_label.config(
                    text=f"Мониторинг запущен для всех объектов: {len(sensor_ids)} датч."
                )
                self.log(f"Запущен постоянный мониторинг всех объектов: {len(sensor_ids)} датчиков")
            else:
                self.stream_status_label.config(
                    text=f"Приём данных запущен для датчика {sensor_ids[0]}"
                )
                self.log(f"Приём данных запущен для датчика {sensor_ids[0]}")

            self.log("Пакеты измерений будут поступать автоматически каждые 1 секунду")
            self.receive_data_packet()

        except Exception as exc:
            messagebox.showerror("Ошибка запуска мониторинга", str(exc))



    def stop_data_stream(self):
        self.stream_running = False
        self.stream_model = None
        self.streams = {}
        self.stream_mode = None

        if self.stream_after_id is not None:
            self.after_cancel(self.stream_after_id)
            self.stream_after_id = None

        self.stream_status_label.config(text="Приём данных остановлен")
        self.log("Мониторинг остановлен")


    def receive_data_packet(self):
        if not self.stream_running or not self.streams:
            return

        try:
            conn = get_connection()

            total_packets = 0
            states_detected = {}

            for sensor_id, stream in list(self.streams.items()):
                packet_index = stream["packet_index"]
                packet = self.generate_stream_packet(
                    packet_index,
                    self.stream_packet_size,
                    rng=stream["rng"],
                    sensor_id=sensor_id
                )

                base_time = stream["start_time"] + timedelta(seconds=packet_index)
                records = []
                for i, value in enumerate(packet):
                    ts = (base_time + timedelta(milliseconds=i * 30)).isoformat(timespec="milliseconds")
                    records.append((sensor_id, ts, float(value)))

                conn.executemany(
                    """
                    INSERT INTO sensor_readings (sensor_id, timestamp, value)
                    VALUES (?, ?, ?)
                    """,
                    records
                )
                conn.commit()

                total_packets += 1

                history_values = get_sensor_values(conn, sensor_id)

                if len(history_values) >= 128:
                    values_for_analysis = history_values[-128:]
                    results = analyze_signal_segment(
                        conn,
                        stream["model"],
                        sensor_id=sensor_id,
                        values=values_for_analysis,
                        window_size=128
                    )

                    dominant = max(
                        ("normal", "wear", "fault"),
                        key=lambda cls: sum(1 for r in results if r["predicted_state"] == cls)
                    )
                    states_detected[sensor_id] = dominant

                stream["packet_index"] += 1

            conn.close()

            if self.stream_mode == "all":
                if states_detected:
                    summary = ", ".join(
                        f"датчик {sid}: {self.get_state_ru(state)}"
                        for sid, state in states_detected.items()
                    )
                    self.log(
                        f"Получены пакеты от {total_packets} датчиков. "
                        f"Анализ: {summary}"
                    )
                else:
                    self.log(
                        f"Получены пакеты от {total_packets} датчиков. "
                        f"Идёт накопление окон анализа..."
                    )
            else:
                sensor_id = next(iter(self.streams.keys()))
                if sensor_id in states_detected:
                    dominant = states_detected[sensor_id]
                    self.log(
                        f"Получен пакет данных: {self.stream_packet_size} измерений. "
                        f"Автоматический анализ: {self.get_state_ru(dominant)}"
                    )

                    if dominant == "wear":
                        self.log("Сформировано предупреждение диспетчеру о признаках износа")
                    elif dominant == "fault":
                        self.log("Сформировано критическое оповещение диспетчеру")
                else:
                    self.log(
                        f"Получен пакет данных: {self.stream_packet_size} измерений. "
                        f"Накопление окна анализа..."
                    )

            self.refresh_data()
            self.stream_after_id = self.after(
                self.stream_interval_ms,
                self.receive_data_packet
            )

        except Exception as exc:
            self.stop_data_stream()
            messagebox.showerror("Ошибка приёма данных", str(exc))

    def open_add_equipment_window(self):
        add_window = tk.Toplevel(self)
        add_window.title("Добавить объект мониторинга")
        add_window.geometry("560x430")
        add_window.resizable(False, False)

        machines = self.get_machines_for_combobox()

        if not machines:
            messagebox.showwarning("Нет техники", "В справочнике техники нет записей.")
            add_window.destroy()
            return

        machine_names = [item["name"] for item in machines]
        machine_by_name = {item["name"]: item for item in machines}

        ttk.Label(add_window, text="Техника из справочника:").pack(anchor="w", padx=15, pady=(15, 5))

        machine_combobox = ttk.Combobox(
            add_window,
            values=machine_names,
            state="readonly",
            width=55
        )
        machine_combobox.pack(padx=15, fill="x")
        machine_combobox.current(0)

        ttk.Label(add_window, text="Ответственный механик:").pack(anchor="w", padx=15, pady=(12, 5))

        mechanic_info_text = tk.Text(add_window, height=5, wrap="word")
        mechanic_info_text.pack(padx=15, fill="x")

        ttk.Label(add_window, text="Контролируемый узел:").pack(anchor="w", padx=15, pady=(12, 5))

        unit_combobox = ttk.Combobox(
            add_window,
            values=["Двигатель", "Редуктор", "Турбина"],
            state="readonly",
            width=55
        )
        unit_combobox.pack(padx=15, fill="x")
        unit_combobox.current(0)

        ttk.Label(add_window, text="Датчик вибрации:").pack(anchor="w", padx=15, pady=(12, 5))

        sensor_entry = ttk.Entry(add_window, width=55)
        sensor_entry.pack(padx=15, fill="x")
        sensor_entry.insert(0, "A603C01")

        def update_mechanic_info(event=None):
            mechanic_info_text.delete("1.0", "end")

            selected_machine_name = machine_combobox.get()
            machine = machine_by_name[selected_machine_name]
            mechanic = self.get_mechanic_by_machine_id(machine["machine_id"])

            if mechanic:
                mechanic_info_text.insert("end", f"ФИО: {mechanic.get('full_name', '-')}\n")
                mechanic_info_text.insert("end", f"Должность: {mechanic.get('position', '-')}\n")
                mechanic_info_text.insert("end", f"Телефон: {mechanic.get('phone', '-')}\n")
                mechanic_info_text.insert("end", f"Email: {mechanic.get('email', '-')}\n")
            else:
                mechanic_info_text.insert("end", "За выбранной техникой механик не закреплен.")

        machine_combobox.bind("<<ComboboxSelected>>", update_mechanic_info)
        update_mechanic_info()

        button_frame = ttk.Frame(add_window)
        button_frame.pack(fill="x", padx=15, pady=20)

        ttk.Button(
            button_frame,
            text="Сохранить",
            command=lambda: self.save_monitoring_object(
                add_window,
                machine_by_name[machine_combobox.get()]["machine_id"],
                unit_combobox.get(),
                sensor_entry.get()
            )
        ).pack(side="left", padx=5)

        ttk.Button(button_frame, text="Отмена", command=add_window.destroy).pack(side="left", padx=5)



    def save_monitoring_object(self, window, machine_id: int, unit_type: str, sensor_name: str):
        sensor_name = sensor_name.strip()
        unit_type = unit_type.strip()

        if not sensor_name:
            messagebox.showwarning("Внимание", "Введите название или модель датчика.")
            return

        try:
            conn = get_connection()
            cursor = conn.cursor()

            unit_row = cursor.execute(
                """
                SELECT unit_id
                FROM units
                WHERE machine_id = ? AND unit_type = ?
                LIMIT 1
                """,
                (machine_id, unit_type)
            ).fetchone()

            if unit_row:
                unit_id = unit_row["unit_id"]

                existing_sensor = cursor.execute(
                    """
                    SELECT sensor_id, name
                    FROM sensors
                    WHERE unit_id = ?
                    ORDER BY sensor_id
                    LIMIT 1
                    """,
                    (unit_id,)
                ).fetchone()

                if existing_sensor:
                    conn.close()

                    self.active_sensor_id = existing_sensor["sensor_id"]
                    self.refresh_data()
                    window.destroy()

                    warning_text = (
                        "Для выбранной техники уже добавлен такой узел.\n\n"
                        f"Техника ID: {machine_id}\n"
                        f"Узел: {unit_type}\n"
                        f"Существующий датчик: {existing_sensor['name']} "
                        f"(ID {existing_sensor['sensor_id']})\n\n"
                        "Повторный объект не создан."
                    )

                    messagebox.showwarning(
                        "Объект уже существует",
                        warning_text
                    )
                    return

            else:
                cursor.execute(
                    """
                    INSERT INTO units (machine_id, name, unit_type, status)
                    VALUES (?, ?, ?, ?)
                    """,
                    (machine_id, unit_type, unit_type, "active")
                )
                unit_id = cursor.lastrowid

            cursor.execute(
                """
                INSERT INTO sensors (unit_id, name, sensor_type, install_date)
                VALUES (?, ?, ?, ?)
                """,
                (
                    unit_id,
                    sensor_name,
                    "Вибродатчик",
                    datetime.now().date().isoformat()
                )
            )

            sensor_id = cursor.lastrowid

            conn.commit()
            conn.close()

            self.active_sensor_id = sensor_id
            self.refresh_data()

            self.log(
                f"Добавлен объект мониторинга: техника ID {machine_id}, "
                f"узел {unit_type}, датчик {sensor_name}, ID датчика {sensor_id}"
            )

            window.destroy()

            messagebox.showinfo(
                "Готово",
                (
                    "Объект мониторинга добавлен.\n\n"
                    f"Узел: {unit_type}\n"
                    f"Датчик: {sensor_name}\n"
                    f"ID датчика: {sensor_id}"
                )
            )

        except Exception as exc:
            messagebox.showerror("Ошибка сохранения", str(exc))

    def load_csv(self):
        sensor_id = self.get_selected_sensor_id()
        if sensor_id is None:
            messagebox.showwarning("Внимание", "Сначала выберите датчик слева.")
            return

        file_path = filedialog.askopenfilename(
            title="Выберите CSV-файл",
            filetypes=[("CSV files", "*.csv")]
        )
        if not file_path:
            return

        try:
            df = load_sensor_csv(file_path)
            df["sensor_id"] = sensor_id

            conn = get_connection()

            records = [
                (int(row.sensor_id), row.timestamp.isoformat(), float(row.value))
                for row in df.itertuples(index=False)
            ]
            conn.executemany(
                """
                INSERT INTO sensor_readings (sensor_id, timestamp, value)
                VALUES (?, ?, ?)
                """,
                records
            )
            conn.commit()

            model = load_model_for_sensor(conn, sensor_id)

            values = df["value"].tolist()
            results = analyze_signal_segment(
                conn,
                model,
                sensor_id=sensor_id,
                values=values,
                window_size=128
            )
            conn.close()

            dominant = max(
                ("normal", "wear", "fault"),
                key=lambda cls: sum(1 for r in results if r["predicted_state"] == cls)
            )

            self.log(f"Загружен архивный файл {Path(file_path).name} для датчика {sensor_id}")
            self.log("Архивные данные добавлены в историю наблюдений")
            self.log(f"Автоматический анализ завершён: {self.get_state_ru(dominant)}")

            if dominant == "wear":
                self.log("Сформировано предупреждение диспетчеру о признаках износа")
            elif dominant == "fault":
                self.log("Сформировано критическое оповещение диспетчеру")

            self.refresh_data()

            messagebox.showinfo(
                "Готово",
                f"Данные успешно загружены.\n"
                f"Итоговый вердикт: {self.get_state_ru(dominant)}"
            )

        except Exception as exc:
            messagebox.showerror("Ошибка загрузки", str(exc))

    def plot_selected_sensor(self):
        sensor_id = self.get_selected_sensor_id()
        if sensor_id is None:
            messagebox.showwarning("Внимание", "Сначала выберите датчик.")
            return

        try:
            conn = get_connection()
            values = get_sensor_values(conn, sensor_id)
            conn.close()

            if not values:
                messagebox.showwarning("Нет данных", "Для выбранного датчика нет измерений.")
                return

            plt.figure(figsize=(10, 4))
            plt.plot(values)
            plt.title(f"График вибрации датчика {sensor_id}")
            plt.xlabel("Номер отсчёта")
            plt.ylabel("Значение")
            plt.grid(True)
            plt.tight_layout()
            plt.show()

            self.log(f"Построен график вибросигнала для датчика {sensor_id}")

        except Exception as exc:
            messagebox.showerror("Ошибка построения графика", str(exc))

    def show_analysis_history_window(self):
        sensor_id = self.get_selected_sensor_id()
        if sensor_id is None:
            messagebox.showwarning("Внимание", "Сначала выберите датчик.")
            return

        conn = get_connection()
        history = get_analysis_history(conn, sensor_id)
        conn.close()

        history_window = tk.Toplevel(self)
        history_window.title(f"История анализов датчика {sensor_id}")
        history_window.geometry("980x540")

        text = tk.Text(history_window, wrap="word", font=("Arial", 11), padx=10, pady=10)
        text.pack(fill="both", expand=True)

        if not history:
            text.insert("end", "История анализов отсутствует.")
            return

        for item in history:
            state_ru = self.get_state_ru(item["dominant_state"])

            text.insert("end", f"Время анализа: {item['analysis_time']}\n")
            text.insert("end", f"Состояние: {state_ru}\n")
            text.insert("end", f"Уверенность: {item['confidence_text']}\n")
            text.insert("end", f"Числовая оценка: {item['average_probability']:.2f}\n")
            text.insert("end", f"Распределение по окнам: {item['counts']}\n")
            text.insert("end", f"Рекомендация: {item['recommendation']}\n")
            text.insert("end", "-" * 90 + "\n")

    def on_sensor_select(self, event=None):
        selected = self.sensor_tree.selection()
        if not selected:
            return

        values = self.sensor_tree.item(selected[0], "values")
        if values:
            self.active_sensor_id = int(values[0])
            self.update_ui_for_selected_sensor()

    def on_tree_click(self, event):
        item = self.sensor_tree.identify_row(event.y)
        if not item:
            self.sensor_tree.selection_remove(self.sensor_tree.selection())
            self.active_sensor_id = None
            self.update_ui_for_selected_sensor()
