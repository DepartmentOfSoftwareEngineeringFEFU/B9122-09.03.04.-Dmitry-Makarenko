from datetime import datetime


def get_equipment_context_for_sensor(conn, sensor_id: int):
    row = conn.execute(
        """
        SELECT
            s.sensor_id,
            s.name AS sensor_name,
            u.unit_id,
            u.name AS unit_name,
            u.unit_type,
            m.machine_id,
            m.name AS machine_name,
            m.model AS machine_model,
            me.mechanic_id,
            me.full_name AS mechanic_name,
            me.position AS mechanic_position,
            me.phone AS mechanic_phone,
            me.email AS mechanic_email
        FROM sensors s
        JOIN units u ON s.unit_id = u.unit_id
        JOIN machines m ON u.machine_id = m.machine_id
        LEFT JOIN machine_mechanics mm ON mm.machine_id = m.machine_id
        LEFT JOIN mechanics me ON me.mechanic_id = mm.mechanic_id
        WHERE s.sensor_id = ?
        ORDER BY mm.id DESC
        LIMIT 1
        """,
        (sensor_id,)
    ).fetchone()

    return dict(row) if row else None


def create_alert(conn, sensor_id: int, unit_id: int, predicted_state: str, probability: float):
    if predicted_state == "normal":
        return None

    if predicted_state == "wear":
        level = "warning"
        message = (
            "Обнаружены признаки износа узла. "
            "Рекомендуется запланировать осмотр для предотвращения серьёзной поломки."
        )
    elif predicted_state == "fault":
        level = "critical"
        message = (
            "Обнаружен сильный износ узла. "
            "Требуется срочное вмешательство механика для предотвращения отказа техники."
        )
    else:
        level = "warning"
        message = "Обнаружено отклонение в работе узла. Требуется дополнительная проверка."

    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO alerts (
            sensor_id,
            unit_id,
            alert_time,
            alert_level,
            message,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            sensor_id,
            unit_id,
            datetime.now().isoformat(timespec="seconds"),
            level,
            f"{message} Уверенность модели: {probability:.2f}.",
            "new"
        )
    )

    conn.commit()
    return cursor.lastrowid


def create_dispatcher_notification(conn, alert_id: int, sensor_id: int, predicted_state: str):
    context = get_equipment_context_for_sensor(conn, sensor_id)
    if context is None:
        return None

    mechanic_id = context.get("mechanic_id")

    mechanic_text = "Ответственный механик не назначен."
    if context.get("mechanic_name"):
        mechanic_text = (
            f"Ответственный механик: {context.get('mechanic_name')}. "
            f"Должность: {context.get('mechanic_position') or '-'}. "
            f"Телефон: {context.get('mechanic_phone') or '-'}. "
            f"Email: {context.get('mechanic_email') or '-'}."
        )

    if predicted_state == "wear":
        title = "ПРЕДУПРЕЖДЕНИЕ ДИСПЕТЧЕРУ."
        state_text = "Состояние: износ. Необходимо запланировать осмотр узла."
    elif predicted_state == "fault":
        title = "КРИТИЧЕСКОЕ ОПОВЕЩЕНИЕ ДИСПЕТЧЕРУ."
        state_text = "Состояние: сильный износ. Требуется срочное вмешательство для предотвращения отказа техники."
    else:
        title = "ОПОВЕЩЕНИЕ ДИСПЕТЧЕРУ."
        state_text = "Состояние: требуется дополнительная проверка."

    message = (
        f"{title} "
        f"Техника: {context.get('machine_name')}. "
        f"Модель: {context.get('machine_model') or '-'}. "
        f"Узел: {context.get('unit_name')}. "
        f"Тип узла: {context.get('unit_type')}. "
        f"Датчик: {context.get('sensor_name')} (ID {context.get('sensor_id')}). "
        f"{state_text} "
        f"{mechanic_text}"
    )

    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO dispatcher_notifications (
            alert_id,
            machine_id,
            unit_id,
            sensor_id,
            mechanic_id,
            notification_time,
            message,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            alert_id,
            context["machine_id"],
            context["unit_id"],
            context["sensor_id"],
            mechanic_id,
            datetime.now().isoformat(timespec="seconds"),
            message,
            "new"
        )
    )

    conn.commit()
    return cursor.lastrowid


def create_dispatcher_notification_if_needed(conn, alert_id: int | None, sensor_id: int, predicted_state: str):
    if alert_id is None:
        return None

    if predicted_state not in ("wear", "fault"):
        return None

    return create_dispatcher_notification(conn, alert_id, sensor_id, predicted_state)
