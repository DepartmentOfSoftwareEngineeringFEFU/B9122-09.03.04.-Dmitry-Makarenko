from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {"timestamp", "sensor_id", "value"}


def load_sensor_csv(file_path: str | Path):
    df = pd.read_csv(file_path)

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"В CSV отсутствуют обязательные столбцы: {missing}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    if df["timestamp"].isna().any():
        raise ValueError("Некорректные значения в столбце timestamp")

    df["sensor_id"] = df["sensor_id"].astype(int)
    df["value"] = df["value"].astype(float)

    return df
