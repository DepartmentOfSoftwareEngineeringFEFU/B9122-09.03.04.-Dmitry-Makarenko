from collections import Counter
from datetime import datetime

from models.feature_extractor import build_feature_dataframe, FEATURE_COLUMNS
from services.alert_service import create_alert, create_dispatcher_notification_if_needed


def get_sensor_values(conn, sensor_id: int) -> list[float]:
    rows = conn.execute(
        """
        SELECT value
        FROM sensor_readings
        WHERE sensor_id = ?
        ORDER BY timestamp
        """,
        (sensor_id,)
    ).fetchall()

    return [row["value"] for row in rows]


def get_unit_id_by_sensor(conn, sensor_id: int) -> int:
    row = conn.execute(
        "SELECT unit_id FROM sensors WHERE sensor_id = ?",
        (sensor_id,)
    ).fetchone()

    if row is None:
        raise ValueError(f"Датчик с ID {sensor_id} не найден")

    return row["unit_id"]


def get_confidence_text(probability: float) -> str:
    if probability < 0.60:
        return "Низкая"
    if probability < 0.80:
        return "Средняя"
    return "Высокая"


def get_state_name_ru(state: str) -> str:
    return {
        "normal": "Норма",
        "wear": "Износ",
        "fault": "Сильный износ",
    }.get(state, state)


def get_recommendation(state: str) -> str:
    recommendations = {
        "normal": "Узел работает в штатном режиме. Рекомендуется продолжить наблюдение.",
        "wear": "Обнаружены признаки износа. Рекомендуется запланировать осмотр узла ответственным механиком.",
        "fault": "Обнаружен сильный износ. Требуется срочное вмешательство механика. Диспетчеру необходимо связаться с ответственным механиком.",
    }
    return recommendations.get(state, "Требуется дополнительная проверка состояния узла.")


def analyze_signal_segment(conn, model, sensor_id: int, values: list[float], window_size: int = 128) -> list[dict]:
    if len(values) < window_size:
        raise ValueError(f"Недостаточно данных для анализа. Нужно минимум {window_size} значений.")

    unit_id = get_unit_id_by_sensor(conn, sensor_id)
    feature_df = build_feature_dataframe(values, window_size=window_size)

    if feature_df.empty:
        raise ValueError("Не удалось сформировать признаки сигнала для анализа.")

    analysis_time = datetime.now().isoformat(timespec="seconds")

    X = feature_df[FEATURE_COLUMNS]
    predicted_labels = model.predict(X)
    predicted_probs = model.predict_proba(X)
    classes = list(model.classes_)

    results = []

    for i, row in feature_df.iterrows():
        predicted_state = predicted_labels[i]
        class_index = classes.index(predicted_state)
        probability = float(predicted_probs[i][class_index])
        window_index = int(row["window_index"])

        conn.execute(
            """
            INSERT INTO signal_features (
                sensor_id, analysis_time, window_index,
                mean, max, min, std, rms, peak_to_peak, crest_factor
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                sensor_id, analysis_time, window_index,
                float(row["mean"]), float(row["max"]), float(row["min"]),
                float(row["std"]), float(row["rms"]), float(row["peak_to_peak"]),
                float(row["crest_factor"]),
            )
        )

        conn.execute(
            """
            INSERT INTO analysis_results (
                sensor_id, unit_id, analysis_time, window_index, predicted_state, probability
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (sensor_id, unit_id, analysis_time, window_index, predicted_state, probability)
        )

        alert_id = create_alert(conn, sensor_id, unit_id, predicted_state, probability)
        create_dispatcher_notification_if_needed(conn, alert_id, sensor_id, predicted_state)

        results.append({
            "analysis_time": analysis_time,
            "window_index": window_index,
            "predicted_state": predicted_state,
            "probability": probability,
        })

    conn.commit()
    return results


def get_latest_sensor_verdict(conn, sensor_id: int) -> dict | None:
    latest_row = conn.execute(
        """
        SELECT analysis_time
        FROM analysis_results
        WHERE sensor_id = ?
        ORDER BY result_id DESC
        LIMIT 1
        """,
        (sensor_id,)
    ).fetchone()

    if latest_row is None:
        return None

    analysis_time = latest_row["analysis_time"]

    rows = conn.execute(
        """
        SELECT predicted_state, probability
        FROM analysis_results
        WHERE sensor_id = ? AND analysis_time = ?
        ORDER BY window_index
        """,
        (sensor_id, analysis_time)
    ).fetchall()

    if not rows:
        return None

    results = [{"predicted_state": row["predicted_state"], "probability": row["probability"]} for row in rows]
    states = [item["predicted_state"] for item in results]
    counter = Counter(states)

    dominant_state = counter.most_common(1)[0][0]
    average_probability = sum(item["probability"] for item in results) / len(results)

    alerts = conn.execute(
        """
        SELECT alert_time, alert_level, message
        FROM alerts
        WHERE sensor_id = ? AND alert_time >= ?
        ORDER BY alert_id DESC
        """,
        (sensor_id, analysis_time)
    ).fetchall()

    dispatcher_notifications = conn.execute(
        """
        SELECT notification_time, message, status
        FROM dispatcher_notifications
        WHERE sensor_id = ? AND notification_time >= ?
        ORDER BY notification_id DESC
        """,
        (sensor_id, analysis_time)
    ).fetchall()

    return {
        "analysis_time": analysis_time,
        "dominant_state": dominant_state,
        "state_name_ru": get_state_name_ru(dominant_state),
        "average_probability": average_probability,
        "confidence_text": get_confidence_text(average_probability),
        "recommendation": get_recommendation(dominant_state),
        "counts": dict(counter),
        "alerts": [dict(row) for row in alerts],
        "dispatcher_notifications": [dict(row) for row in dispatcher_notifications],
    }


def get_analysis_history(conn, sensor_id: int) -> list[dict]:
    rows = conn.execute(
        """
        SELECT analysis_time, predicted_state, probability
        FROM analysis_results
        WHERE sensor_id = ?
        ORDER BY analysis_time DESC, window_index ASC
        """,
        (sensor_id,)
    ).fetchall()

    if not rows:
        return []

    grouped = {}

    for row in rows:
        grouped.setdefault(row["analysis_time"], []).append({
            "predicted_state": row["predicted_state"],
            "probability": row["probability"],
        })

    history = []

    for analysis_time, items in grouped.items():
        states = [item["predicted_state"] for item in items]
        counter = Counter(states)
        dominant_state = counter.most_common(1)[0][0]
        average_probability = sum(item["probability"] for item in items) / len(items)

        history.append({
            "analysis_time": analysis_time,
            "dominant_state": dominant_state,
            "state_name_ru": get_state_name_ru(dominant_state),
            "confidence_text": get_confidence_text(average_probability),
            "average_probability": average_probability,
            "recommendation": get_recommendation(dominant_state),
            "counts": dict(counter),
        })

    history.sort(key=lambda item: item["analysis_time"], reverse=True)
    return history
