import numpy as np
import pandas as pd

FEATURE_COLUMNS = ["mean", "max", "min", "std", "rms", "peak_to_peak", "crest_factor"]


def split_signal_into_windows(values, window_size=128):
    arr = np.array(values, dtype=float)
    windows = []

    for start in range(0, len(arr), window_size):
        window = arr[start:start + window_size]
        if len(window) == window_size:
            windows.append(window)

    return windows


def extract_features(window):
    mean_val = float(np.mean(window))
    max_val = float(np.max(window))
    min_val = float(np.min(window))
    std_val = float(np.std(window))
    rms_val = float(np.sqrt(np.mean(np.square(window))))
    peak_to_peak = float(max_val - min_val)
    crest_factor = float(max(abs(max_val), abs(min_val)) / rms_val) if rms_val != 0 else 0.0

    return {
        "mean": mean_val,
        "max": max_val,
        "min": min_val,
        "std": std_val,
        "rms": rms_val,
        "peak_to_peak": peak_to_peak,
        "crest_factor": crest_factor,
    }


def build_feature_dataframe(values, window_size=128):
    windows = split_signal_into_windows(values, window_size)
    rows = []

    for idx, window in enumerate(windows):
        features = extract_features(window)
        features["window_index"] = idx
        rows.append(features)

    return pd.DataFrame(rows)
