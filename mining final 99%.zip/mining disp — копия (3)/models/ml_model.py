from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier

from config import MODEL_DIR
from models.feature_extractor import FEATURE_COLUMNS, extract_features


UNIT_TYPE_MAP = {
    "редуктор": "gearbox",
    "двигатель": "engine",
    "мотор": "engine",
    "турбина": "turbine",
}

# Версия модели нужна, чтобы после изменения логики обучения программа
# не использовала старые сохранённые .joblib-файлы.
MODEL_VERSION = "v3"


def normalize_unit_type(unit_type: str) -> str:
    if not unit_type:
        return "default"
    return UNIT_TYPE_MAP.get(unit_type.strip().lower(), "default")


def get_model_path(unit_type: str) -> Path:
    return MODEL_DIR / f"rf_model_{normalize_unit_type(unit_type)}_{MODEL_VERSION}.joblib"


def _unit_base_params(unit_key: str):
    """
    Базовые параметры нормального вибросигнала для разных типов узлов.
    Значения условные, используются для дипломной демонстрации.
    """
    if unit_key == "engine":
        return {
            "a1": 0.30,
            "a2": 0.10,
            "f1": 0.11,
            "f2": 0.37,
            "noise": 0.035,
        }

    if unit_key == "gearbox":
        return {
            "a1": 0.25,
            "a2": 0.08,
            "f1": 0.12,
            "f2": 0.42,
            "noise": 0.035,
        }

    if unit_key == "turbine":
        return {
            "a1": 0.18,
            "a2": 0.06,
            "f1": 0.16,
            "f2": 0.55,
            "noise": 0.025,
        }

    return {
        "a1": 0.25,
        "a2": 0.08,
        "f1": 0.12,
        "f2": 0.42,
        "noise": 0.035,
    }


def _generate_signal_window(unit_key: str, state: str, rng, window_size: int = 128):
    """
    Генерирует ОДНО окно вибросигнала без готовой метки внутри данных.

    Метка state используется только для обучения демонстрационной модели.
    В реальной работе модель получает только числовой сигнал.
    """
    params = _unit_base_params(unit_key)

    phase = rng.uniform(0, 2 * np.pi)
    t = np.arange(window_size) + rng.integers(0, 10_000)

    base = (
        params["a1"] * np.sin(params["f1"] * t + phase)
        + params["a2"] * np.sin(params["f2"] * t + phase / 2)
    )

    if state == "normal":
        signal = base + rng.normal(0, params["noise"], size=window_size)

    elif state == "wear":
        signal = (
            base * 1.9
            + rng.normal(0, params["noise"] * 2.0, size=window_size)
            + 0.10 * np.sin(0.75 * t + phase)
        )

    elif state == "fault":
        signal = (
            base * 3.4
            + rng.normal(0, params["noise"] * 3.0, size=window_size)
            + 0.18 * np.sin(0.95 * t + phase)
        )

        spike_count = max(3, window_size // 18)
        spike_idx = rng.choice(np.arange(window_size), size=spike_count, replace=False)
        signal[spike_idx] += rng.uniform(1.0, 2.2, size=spike_count)

    else:
        raise ValueError(f"Неизвестное состояние для генерации: {state}")

    return signal


def generate_demo_training_data(unit_type: str, n_per_class: int = 350):
    """
    Формирует демонстрационный обучающий набор на основе синтетических окон сигнала.

    Почему так:
    - раньше обучающие признаки и тестовые CSV немного расходились по диапазонам;
    - из-за этого нормальный файл мог классифицироваться как износ;
    - теперь модель обучается на сигналах, похожих на потоковый генератор и тестовые CSV.
    """
    rng = np.random.default_rng(42)
    unit_key = normalize_unit_type(unit_type)

    rows = []

    for state in ("normal", "wear", "fault"):
        for _ in range(n_per_class):
            window = _generate_signal_window(unit_key, state, rng, window_size=128)
            features = extract_features(window)
            features["label"] = state
            rows.append(features)

    return pd.DataFrame(rows)


def train_model_for_unit_type(unit_type: str):
    df = generate_demo_training_data(unit_type)

    X = df[FEATURE_COLUMNS]
    y = df["label"]

    model = RandomForestClassifier(
        n_estimators=250,
        random_state=42,
        class_weight="balanced"
    )
    model.fit(X, y)

    path = get_model_path(unit_type)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, path)

    return model


def load_model_for_unit_type(unit_type: str):
    path = get_model_path(unit_type)

    if not path.exists():
        return train_model_for_unit_type(unit_type)

    return joblib.load(path)


def load_model_for_sensor(conn, sensor_id: int):
    row = conn.execute(
        """
        SELECT u.unit_type
        FROM sensors s
        JOIN units u ON s.unit_id = u.unit_id
        WHERE s.sensor_id = ?
        """,
        (sensor_id,)
    ).fetchone()

    if row is None:
        raise ValueError(f"Не найден тип узла для датчика {sensor_id}")

    return load_model_for_unit_type(row["unit_type"])
