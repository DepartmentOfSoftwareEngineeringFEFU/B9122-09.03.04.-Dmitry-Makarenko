# ui/app.py
import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from datetime import datetime

import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Добавляем корневую папку проекта в путь поиска модулей
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.db import get_connection
from services.data_loader import load_sensor_csv
from models.ml_model import load_model_for_sensor
from services.analysis_service import (
    get_sensor_values,
    analyze_signal_segment,
    get_latest_sensor_verdict,
    get_analysis_history
)


class MonitoringApp(tk.Tk):
    """Главное окно программной системы мониторинга состояния горной техники."""

    STATE_LEVELS = {"normal": 0, "wear": 1, "fault": 2}
    STATE_NAMES = {"normal": "Норма", "wear": "Износ", "fault": "Сильный износ"}

    def __init__(self):
        super().__init__()

        self.title("Система мониторинга состояния горной техники")
        self.geometry("1400x800")
        self.minsize(1200, 700)

        self.conn = get_connection()

        self.current_machine_id = None
        self.current_unit_id = None
        self.current_sensor_id = None
        self.current_frame = None

        self._setup_style()
        self._setup_ui()

        self.refresh_object_tree()
        self.refresh_notifications()

    # ------------------------------------------------------------------
    # ОБЩИЙ СТИЛЬ
    # ------------------------------------------------------------------

    def _setup_style(self):
        """Настраивает простой единый стиль без произвольного темного оформления."""
        style = ttk.Style(self)

        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", font=("Arial", 10))
        style.configure("TButton", padding=5)
        style.configure("Treeview", rowheight=26)
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"))
        style.configure("Title.TLabel", font=("Arial", 13, "bold"))
        style.configure("Block.TLabelframe.Label", font=("Arial", 10, "bold"))

    # ------------------------------------------------------------------
    # ОСНОВНОЙ ИНТЕРФЕЙС
    # ------------------------------------------------------------------

    def _setup_ui(self):
        """Создает основное окно согласно проекту интерфейса из главы 3.5."""
        main_container = ttk.Frame(self)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Левая часть: меню и список техники / узлов / датчиков
        left_panel = ttk.Frame(main_container, width=300)
        left_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 5))
        left_panel.pack_propagate(False)

        menu_frame = ttk.LabelFrame(left_panel, text="Меню", style="Block.TLabelframe")
        menu_frame.pack(fill=tk.X, pady=(0, 5))

        ttk.Button(menu_frame, text="Главный экран", command=self.show_main_screen).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Добавить объект мониторинга", command=self.show_add_monitoring_object).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Загрузить архив CSV", command=self.load_csv_data).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Запустить анализ", command=self.run_analysis).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Просмотр БД", command=self.show_database_view).pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(menu_frame, text="Изменить справочники", command=self.show_directories_editor).pack(fill=tk.X, padx=5, pady=2)

        object_frame = ttk.LabelFrame(left_panel, text="Техника, узлы и датчики", style="Block.TLabelframe")
        object_frame.pack(fill=tk.BOTH, expand=True)

        self.object_tree = ttk.Treeview(object_frame, show="tree", height=20)
        self.object_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        object_scroll = ttk.Scrollbar(object_frame, orient=tk.VERTICAL, command=self.object_tree.yview)
        object_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.object_tree.configure(yscrollcommand=object_scroll.set)

        self.object_tree.tag_configure("normal", background="#FFFFFF")
        self.object_tree.tag_configure("wear", background="#FFF4CC")
        self.object_tree.tag_configure("fault", background="#FFD6D6")
        self.object_tree.tag_configure("nodata", background="#FFFFFF")

        self.object_tree.bind("<<TreeviewSelect>>", self.on_object_tree_select)

        # Центральная часть
        self.center_panel = ttk.Frame(main_container)
        self.center_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Правая часть: оповещения диспетчеру
        right_panel = ttk.Frame(main_container, width=350)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 0))
        right_panel.pack_propagate(False)

        notifications_frame = ttk.LabelFrame(right_panel, text="Оповещения диспетчеру", style="Block.TLabelframe")
        notifications_frame.pack(fill=tk.BOTH, expand=True)

        self.notifications_listbox = tk.Listbox(
            notifications_frame,
            height=25,
            font=("Arial", 10),
            activestyle="none"
        )
        self.notifications_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)

        notif_scroll = ttk.Scrollbar(notifications_frame, orient=tk.VERTICAL, command=self.notifications_listbox.yview)
        notif_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.notifications_listbox.configure(yscrollcommand=notif_scroll.set)

        self.show_main_screen()

    def clear_center(self):
        for widget in self.center_panel.winfo_children():
            widget.destroy()

    def _get_state_tag(self, state_text):
        text = str(state_text or "").lower()

        if "силь" in text or "fault" in text or "крит" in text:
            return "fault"
        if "износ" in text or "wear" in text:
            return "wear"
        if "норма" in text or "normal" in text:
            return "normal"

        return "nodata"

    def _get_latest_state_for_sensor(self, sensor_id):
        verdict = get_latest_sensor_verdict(self.conn, sensor_id)
        if verdict:
            return verdict.get("state_name_ru", "Нет данных")
        return "Нет данных"

    # ------------------------------------------------------------------
    # ЛЕВОЕ ДЕРЕВО ОБЪЕКТОВ
    # ------------------------------------------------------------------

    def refresh_object_tree(self):
        """Обновляет дерево техники, узлов и датчиков в левой части окна."""
        if not hasattr(self, "object_tree"):
            return

        self.object_tree.delete(*self.object_tree.get_children())

        cursor = self.conn.cursor()
        machines = cursor.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()

        for machine in machines:
            machine_id = machine["machine_id"]

            machine_node = self.object_tree.insert(
                "",
                tk.END,
                iid=f"machine_{machine_id}",
                text=f"{machine['name']} ({machine['model'] or '-'})",
                open=True
            )

            units = cursor.execute(
                "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
                (machine_id,)
            ).fetchall()

            for unit in units:
                unit_id = unit["unit_id"]

                sensor = cursor.execute(
                    "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                    (unit_id,)
                ).fetchone()

                state_text = "Нет данных"
                tag = "nodata"

                if sensor:
                    state_text = self._get_latest_state_for_sensor(sensor["sensor_id"])
                    tag = self._get_state_tag(state_text)

                unit_node = self.object_tree.insert(
                    machine_node,
                    tk.END,
                    iid=f"unit_{unit_id}",
                    text=f"{unit['name']} / {unit['unit_type']} — {state_text}",
                    open=True,
                    tags=(tag,)
                )

                if sensor:
                    self.object_tree.insert(
                        unit_node,
                        tk.END,
                        iid=f"sensor_{sensor['sensor_id']}",
                        text=f"Датчик: {sensor['name']} (ID {sensor['sensor_id']})",
                        tags=(tag,)
                    )

    def on_object_tree_select(self, event):
        selected = self.object_tree.selection()
        if not selected:
            return

        item_id = selected[0]

        if item_id.startswith("machine_"):
            self.current_machine_id = int(item_id.replace("machine_", ""))
            self.current_unit_id = None
            self.current_sensor_id = None
            self.show_machine_details()

        elif item_id.startswith("unit_"):
            self.current_unit_id = int(item_id.replace("unit_", ""))
            self._set_current_by_unit()
            self.show_unit_details()

        elif item_id.startswith("sensor_"):
            self.current_sensor_id = int(item_id.replace("sensor_", ""))
            self._set_current_by_sensor()
            self.show_unit_details()

    def _set_current_by_unit(self):
        cursor = self.conn.cursor()
        unit = cursor.execute("SELECT * FROM units WHERE unit_id = ?", (self.current_unit_id,)).fetchone()

        if unit:
            self.current_machine_id = unit["machine_id"]

        sensor = cursor.execute("SELECT * FROM sensors WHERE unit_id = ? LIMIT 1", (self.current_unit_id,)).fetchone()
        if sensor:
            self.current_sensor_id = sensor["sensor_id"]

    def _set_current_by_sensor(self):
        cursor = self.conn.cursor()
        row = cursor.execute("""
            SELECT u.unit_id, u.machine_id
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            WHERE s.sensor_id = ?
        """, (self.current_sensor_id,)).fetchone()

        if row:
            self.current_unit_id = row["unit_id"]
            self.current_machine_id = row["machine_id"]

    # ------------------------------------------------------------------
    # 3.5.1 ГЛАВНЫЙ ЭКРАН
    # ------------------------------------------------------------------

    def show_main_screen(self):
        """Главный экран диспетчера."""
        self.clear_center()
        self.current_frame = "main"

        title = ttk.Label(self.center_panel, text="Главный экран диспетчера", style="Title.TLabel")
        title.pack(anchor=tk.W, pady=(0, 5))

        table_frame = ttk.LabelFrame(self.center_panel, text="Контролируемая техника", style="Block.TLabelframe")
        table_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        columns = ("machine", "unit", "sensor", "state", "updated")
        self.main_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)

        self.main_tree.heading("machine", text="Техника")
        self.main_tree.heading("unit", text="Контролируемый узел")
        self.main_tree.heading("sensor", text="Датчик")
        self.main_tree.heading("state", text="Состояние")
        self.main_tree.heading("updated", text="Последнее обновление")

        self.main_tree.column("machine", width=180)
        self.main_tree.column("unit", width=160)
        self.main_tree.column("sensor", width=130)
        self.main_tree.column("state", width=130)
        self.main_tree.column("updated", width=160)

        self.main_tree.tag_configure("normal", background="#FFFFFF")
        self.main_tree.tag_configure("wear", background="#FFF4CC")
        self.main_tree.tag_configure("fault", background="#FFD6D6")
        self.main_tree.tag_configure("nodata", background="#FFFFFF")

        main_scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.main_tree.yview)
        self.main_tree.configure(yscrollcommand=main_scroll.set)

        self.main_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        main_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        self.main_tree.bind("<<TreeviewSelect>>", self.on_main_table_select)

        details_frame = ttk.LabelFrame(self.center_panel, text="Выбранная техника и последний анализ", style="Block.TLabelframe")
        details_frame.pack(fill=tk.BOTH, expand=True)

        self.details_text = tk.Text(details_frame, height=10, font=("Arial", 10), wrap=tk.WORD)
        self.details_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.refresh_main_table()

    def refresh_main_table(self):
        if not hasattr(self, "main_tree"):
            return

        self.main_tree.delete(*self.main_tree.get_children())

        cursor = self.conn.cursor()
        rows = cursor.execute("""
            SELECT
                m.machine_id,
                m.name AS machine_name,
                u.unit_id,
                u.name AS unit_name,
                u.unit_type,
                s.sensor_id,
                s.name AS sensor_name
            FROM machines m
            LEFT JOIN units u ON u.machine_id = m.machine_id
            LEFT JOIN sensors s ON s.unit_id = u.unit_id
            ORDER BY m.machine_id, u.unit_id, s.sensor_id
        """).fetchall()

        for row in rows:
            state_text = "Нет данных"
            updated = "-"

            if row["sensor_id"]:
                verdict = get_latest_sensor_verdict(self.conn, row["sensor_id"])
                if verdict:
                    state_text = verdict.get("state_name_ru", "Нет данных")
                    updated = verdict.get("analysis_time", "-")

            tag = self._get_state_tag(state_text)

            item_id = f"row_{row['machine_id']}_{row['unit_id'] or 0}_{row['sensor_id'] or 0}"

            self.main_tree.insert(
                "",
                tk.END,
                iid=item_id,
                values=(
                    row["machine_name"] or "-",
                    row["unit_name"] or "-",
                    row["sensor_name"] or "-",
                    state_text,
                    updated
                ),
                tags=(tag,)
            )

    def on_main_table_select(self, event):
        selected = self.main_tree.selection()
        if not selected:
            return

        parts = selected[0].split("_")

        try:
            self.current_machine_id = int(parts[1])
            self.current_unit_id = int(parts[2]) if int(parts[2]) != 0 else None
            self.current_sensor_id = int(parts[3]) if int(parts[3]) != 0 else None
        except Exception:
            return

        if self.current_unit_id:
            self.show_unit_details()
        else:
            self.show_machine_details()

    def show_machine_details(self):
        if not self.current_machine_id:
            return

        if self.current_frame != "main":
            self.show_main_screen()

        cursor = self.conn.cursor()
        machine = cursor.execute(
            "SELECT * FROM machines WHERE machine_id = ?",
            (self.current_machine_id,)
        ).fetchone()

        if not machine:
            return

        units = cursor.execute(
            "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
            (self.current_machine_id,)
        ).fetchall()

        text = ""
        text += f"Наименование: {machine['name']}\n"
        text += f"Модель: {machine['model'] or '-'}\n"
        text += f"Тип: {machine['type'] or '-'}\n"
        text += f"Статус: {machine['status'] or '-'}\n\n"
        text += "Состояние узлов:\n"

        for unit in units:
            sensor = cursor.execute("SELECT * FROM sensors WHERE unit_id = ?", (unit["unit_id"],)).fetchone()
            state_text = "Нет данных"

            if sensor:
                state_text = self._get_latest_state_for_sensor(sensor["sensor_id"])

            text += f"- {unit['name']} ({unit['unit_type']}): {state_text}\n"

        self.details_text.delete(1.0, tk.END)
        self.details_text.insert(1.0, text)

    def show_unit_details(self):
        if not self.current_unit_id:
            return

        if self.current_frame != "main":
            self.show_main_screen()

        cursor = self.conn.cursor()

        row = cursor.execute("""
            SELECT
                m.name AS machine_name,
                m.model,
                m.type,
                m.status,
                u.name AS unit_name,
                u.unit_type,
                s.sensor_id,
                s.name AS sensor_name
            FROM units u
            JOIN machines m ON u.machine_id = m.machine_id
            LEFT JOIN sensors s ON s.unit_id = u.unit_id
            WHERE u.unit_id = ?
        """, (self.current_unit_id,)).fetchone()

        if not row:
            return

        text = ""
        text += f"Техника: {row['machine_name']}\n"
        text += f"Модель: {row['model'] or '-'}\n"
        text += f"Тип техники: {row['type'] or '-'}\n"
        text += f"Статус техники: {row['status'] or '-'}\n\n"
        text += f"Контролируемый узел: {row['unit_name']}\n"
        text += f"Тип узла: {row['unit_type']}\n"
        text += f"Датчик: {row['sensor_name'] or '-'}\n"

        if row["sensor_id"]:
            verdict = get_latest_sensor_verdict(self.conn, row["sensor_id"])
            text += "\nПоследний результат анализа:\n"

            if verdict:
                text += f"Состояние: {verdict.get('state_name_ru', 'Нет данных')}\n"
                text += f"Уверенность: {verdict.get('average_probability', 0):.2f}\n"
                text += f"Дата/время анализа: {verdict.get('analysis_time', '-')}\n"
                text += f"Рекомендация: {verdict.get('recommendation', '-')}\n"
            else:
                text += "Нет данных анализа.\n"

        self.details_text.delete(1.0, tk.END)
        self.details_text.insert(1.0, text)

    # ------------------------------------------------------------------
    # 3.5.2 ДОБАВЛЕНИЕ ОБЪЕКТА МОНИТОРИНГА
    # ------------------------------------------------------------------

    def show_add_monitoring_object(self):
        """Окно добавления объекта мониторинга."""
        win = tk.Toplevel(self)
        win.title("Добавление объекта мониторинга")
        win.geometry("500x360")
        win.transient(self)
        win.grab_set()

        cursor = self.conn.cursor()

        machines = cursor.execute("SELECT machine_id, name FROM machines ORDER BY machine_id").fetchall()
        mechanics = cursor.execute("""
            SELECT
                m.machine_id,
                me.full_name
            FROM machine_mechanics mm
            JOIN machines m ON mm.machine_id = m.machine_id
            JOIN mechanics me ON mm.mechanic_id = me.mechanic_id
        """).fetchall()

        mechanic_by_machine = {row["machine_id"]: row["full_name"] for row in mechanics}

        ttk.Label(win, text="Выберите технику:").pack(anchor=tk.W, padx=10, pady=(10, 2))

        machine_values = [f"{m['machine_id']} — {m['name']}" for m in machines]
        machine_var = tk.StringVar()

        machine_combo = ttk.Combobox(win, textvariable=machine_var, values=machine_values, state="readonly")
        machine_combo.pack(fill=tk.X, padx=10)

        mechanic_label = ttk.Label(win, text="Ответственный механик: -")
        mechanic_label.pack(anchor=tk.W, padx=10, pady=(8, 2))

        ttk.Label(win, text="Тип контролируемого узла:").pack(anchor=tk.W, padx=10, pady=(10, 2))

        unit_type_var = tk.StringVar(value="Двигатель")
        unit_type_combo = ttk.Combobox(
            win,
            textvariable=unit_type_var,
            values=["Двигатель", "Редуктор", "Турбина"],
            state="readonly"
        )
        unit_type_combo.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Наименование узла:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        unit_name_entry = ttk.Entry(win)
        unit_name_entry.pack(fill=tk.X, padx=10)

        ttk.Label(win, text="Наименование датчика:").pack(anchor=tk.W, padx=10, pady=(10, 2))
        sensor_name_entry = ttk.Entry(win)
        sensor_name_entry.pack(fill=tk.X, padx=10)

        def get_selected_machine_id():
            value = machine_var.get()
            if not value:
                return None
            return int(value.split("—")[0].strip())

        def on_machine_change(event=None):
            machine_id = get_selected_machine_id()
            if not machine_id:
                mechanic_label.config(text="Ответственный механик: -")
                return

            mechanic_name = mechanic_by_machine.get(machine_id, "не закреплен")
            mechanic_label.config(text=f"Ответственный механик: {mechanic_name}")

        machine_combo.bind("<<ComboboxSelected>>", on_machine_change)

        def save_object():
            machine_id = get_selected_machine_id()
            unit_type = unit_type_var.get()
            unit_name = unit_name_entry.get().strip()
            sensor_name = sensor_name_entry.get().strip()

            if not machine_id:
                messagebox.showerror("Ошибка", "Выберите технику.")
                return

            if not unit_name:
                unit_name = unit_type

            if not sensor_name:
                sensor_name = f"Датчик {unit_type}"

            duplicate = cursor.execute(
                "SELECT 1 FROM units WHERE machine_id = ? AND unit_type = ?",
                (machine_id, unit_type)
            ).fetchone()

            if duplicate:
                messagebox.showerror(
                    "Ошибка",
                    "Для выбранной техники уже существует узел такого типа."
                )
                return

            cursor.execute(
                "INSERT INTO units (machine_id, name, unit_type) VALUES (?, ?, ?)",
                (machine_id, unit_name, unit_type)
            )
            unit_id = cursor.lastrowid

            cursor.execute(
                "INSERT INTO sensors (unit_id, name) VALUES (?, ?)",
                (unit_id, sensor_name)
            )

            self.conn.commit()

            messagebox.showinfo("Готово", "Объект мониторинга добавлен.")
            win.destroy()

            self.refresh_object_tree()
            self.refresh_main_table()

        ttk.Button(win, text="Добавить объект", command=save_object).pack(fill=tk.X, padx=10, pady=(20, 5))
        ttk.Button(win, text="Отмена", command=win.destroy).pack(fill=tk.X, padx=10, pady=5)

    # ------------------------------------------------------------------
    # 3.5.3 СПРАВОЧНИКИ
    # ------------------------------------------------------------------

    def show_directories_editor(self):
        """Окна изменения справочников. Доступ только после пароля."""
        password = simpledialog.askstring(
            "Доступ к справочникам",
            "Введите пароль администратора:",
            show="*"
        )

        if password != "admin":
            messagebox.showerror("Ошибка", "Неверный пароль. Доступ запрещен.")
            return

        self.clear_center()
        self.current_frame = "directories"

        ttk.Label(self.center_panel, text="Изменение справочников", style="Title.TLabel").pack(anchor=tk.W, pady=(0, 5))

        notebook = ttk.Notebook(self.center_panel)
        notebook.pack(fill=tk.BOTH, expand=True)

        machines_frame = ttk.Frame(notebook)
        units_frame = ttk.Frame(notebook)
        sensors_frame = ttk.Frame(notebook)
        mechanics_frame = ttk.Frame(notebook)
        assignments_frame = ttk.Frame(notebook)

        notebook.add(machines_frame, text="Техника")
        notebook.add(units_frame, text="Узлы")
        notebook.add(sensors_frame, text="Датчики")
        notebook.add(mechanics_frame, text="Механики")
        notebook.add(assignments_frame, text="Закрепления")

        self._create_machines_editor(machines_frame)
        self._create_units_editor(units_frame)
        self._create_sensors_editor(sensors_frame)
        self._create_mechanics_editor(mechanics_frame)
        self._create_assignments_editor(assignments_frame)

    def _create_simple_tree(self, parent, columns, headings):
        tree = ttk.Treeview(parent, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=headings.get(col, col))
            tree.column(col, width=120)

        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        return tree

    def _create_machines_editor(self, parent):
        columns = ("id", "name", "model", "type", "status")
        headings = {
            "id": "ID",
            "name": "Наименование",
            "model": "Модель",
            "type": "Тип",
            "status": "Статус"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())
            rows = self.conn.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()
            for row in rows:
                tree.insert("", tk.END, values=(
                    row["machine_id"],
                    row["name"],
                    row["model"] or "-",
                    row["type"] or "-",
                    row["status"] or "-"
                ))

        def add():
            name = simpledialog.askstring("Техника", "Наименование техники:")
            if not name:
                return
            model = simpledialog.askstring("Техника", "Модель:")
            type_ = simpledialog.askstring("Техника", "Тип:")
            status = simpledialog.askstring("Техника", "Статус:")

            self.conn.execute(
                "INSERT INTO machines (name, model, type, status) VALUES (?, ?, ?, ?)",
                (name, model or "", type_ or "", status or "active")
            )
            self.conn.commit()
            refresh()
            self.refresh_object_tree()
            self.refresh_main_table()

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранную технику?"):
                self.conn.execute("DELETE FROM machines WHERE machine_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self.refresh_object_tree()
                self.refresh_main_table()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_units_editor(self, parent):
        columns = ("id", "machine", "name", "type")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "name": "Узел",
            "type": "Тип узла"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    u.unit_id,
                    m.name AS machine_name,
                    u.name,
                    u.unit_type
                FROM units u
                JOIN machines m ON u.machine_id = m.machine_id
                ORDER BY u.unit_id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["unit_id"],
                    row["machine_name"],
                    row["name"],
                    row["unit_type"]
                ))

        def add():
            self.show_add_monitoring_object()
            refresh()

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранный узел?"):
                self.conn.execute("DELETE FROM units WHERE unit_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self.refresh_object_tree()
                self.refresh_main_table()

        ttk.Button(btn_frame, text="Добавить объект мониторинга", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_sensors_editor(self, parent):
        columns = ("id", "machine", "unit", "sensor")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "unit": "Узел",
            "sensor": "Датчик"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    s.sensor_id,
                    s.name AS sensor_name,
                    u.name AS unit_name,
                    m.name AS machine_name
                FROM sensors s
                JOIN units u ON s.unit_id = u.unit_id
                JOIN machines m ON u.machine_id = m.machine_id
                ORDER BY s.sensor_id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["sensor_id"],
                    row["machine_name"],
                    row["unit_name"],
                    row["sensor_name"]
                ))

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранный датчик?"):
                self.conn.execute("DELETE FROM sensors WHERE sensor_id = ?", (values[0],))
                self.conn.commit()
                refresh()
                self.refresh_object_tree()
                self.refresh_main_table()

        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_mechanics_editor(self, parent):
        columns = ("id", "full_name", "position", "phone", "email")
        headings = {
            "id": "ID",
            "full_name": "ФИО",
            "position": "Должность",
            "phone": "Телефон",
            "email": "E-mail"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())
            rows = self.conn.execute("SELECT * FROM mechanics ORDER BY mechanic_id").fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["mechanic_id"],
                    row["full_name"],
                    row["position"] or "-",
                    row["phone"] or "-",
                    row["email"] or "-"
                ))

        def add():
            full_name = simpledialog.askstring("Механик", "ФИО механика:")
            if not full_name:
                return

            position = simpledialog.askstring("Механик", "Должность:")
            phone = simpledialog.askstring("Механик", "Телефон:")
            email = simpledialog.askstring("Механик", "E-mail:")

            self.conn.execute(
                "INSERT INTO mechanics (full_name, position, phone, email) VALUES (?, ?, ?, ?)",
                (full_name, position or "", phone or "", email or "")
            )
            self.conn.commit()
            refresh()

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить выбранного механика?"):
                self.conn.execute("DELETE FROM mechanics WHERE mechanic_id = ?", (values[0],))
                self.conn.commit()
                refresh()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    def _create_assignments_editor(self, parent):
        columns = ("id", "machine", "mechanic", "date")
        headings = {
            "id": "ID",
            "machine": "Техника",
            "mechanic": "Механик",
            "date": "Дата закрепления"
        }

        tree = self._create_simple_tree(parent, columns, headings)

        btn_frame = ttk.Frame(parent)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)

        def refresh():
            tree.delete(*tree.get_children())

            rows = self.conn.execute("""
                SELECT
                    mm.id,
                    m.name AS machine_name,
                    me.full_name AS mechanic_name,
                    mm.assignment_date
                FROM machine_mechanics mm
                JOIN machines m ON mm.machine_id = m.machine_id
                JOIN mechanics me ON mm.mechanic_id = me.mechanic_id
                ORDER BY mm.id
            """).fetchall()

            for row in rows:
                tree.insert("", tk.END, values=(
                    row["id"],
                    row["machine_name"],
                    row["mechanic_name"],
                    row["assignment_date"] or "-"
                ))

        def add():
            cursor = self.conn.cursor()

            machines = cursor.execute("SELECT machine_id, name FROM machines ORDER BY machine_id").fetchall()
            mechanics = cursor.execute("SELECT mechanic_id, full_name FROM mechanics ORDER BY mechanic_id").fetchall()

            if not machines or not mechanics:
                messagebox.showwarning("Внимание", "Нет техники или механиков для закрепления.")
                return

            machine_text = "\n".join([f"{m['machine_id']}: {m['name']}" for m in machines])
            machine_id = simpledialog.askinteger("Закрепление", "Введите ID техники:\n" + machine_text)

            if not machine_id:
                return

            mechanic_text = "\n".join([f"{m['mechanic_id']}: {m['full_name']}" for m in mechanics])
            mechanic_id = simpledialog.askinteger("Закрепление", "Введите ID механика:\n" + mechanic_text)

            if not mechanic_id:
                return

            cursor.execute(
                "INSERT INTO machine_mechanics (machine_id, mechanic_id, assignment_date) VALUES (?, ?, ?)",
                (machine_id, mechanic_id, datetime.now().isoformat(timespec="seconds"))
            )
            self.conn.commit()
            refresh()

        def delete():
            selected = tree.selection()
            if not selected:
                return

            values = tree.item(selected[0])["values"]
            if messagebox.askyesno("Удаление", "Удалить закрепление?"):
                self.conn.execute("DELETE FROM machine_mechanics WHERE id = ?", (values[0],))
                self.conn.commit()
                refresh()

        ttk.Button(btn_frame, text="Добавить", command=add).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Удалить", command=delete).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="Обновить", command=refresh).pack(side=tk.LEFT, padx=3)

        refresh()

    # ------------------------------------------------------------------
    # 3.5.4 ПРОСМОТР БАЗЫ ДАННЫХ
    # ------------------------------------------------------------------

    def show_database_view(self):
        """Окно просмотра базы данных."""
        self.clear_center()
        self.current_frame = "database"

        ttk.Label(self.center_panel, text="Просмотр базы данных", style="Title.TLabel").pack(anchor=tk.W, pady=(0, 5))

        top_frame = ttk.LabelFrame(self.center_panel, text="Основная таблица техники", style="Block.TLabelframe")
        top_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))

        columns = ("id", "name", "model", "type", "status")
        self.db_machines_tree = ttk.Treeview(top_frame, columns=columns, show="headings", height=8)

        headings = {
            "id": "ID",
            "name": "Наименование",
            "model": "Модель",
            "type": "Тип",
            "status": "Статус"
        }

        for col in columns:
            self.db_machines_tree.heading(col, text=headings[col])
            self.db_machines_tree.column(col, width=120)

        self.db_machines_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.db_machines_tree.bind("<<TreeviewSelect>>", self.on_db_machine_select)

        control_frame = ttk.Frame(self.center_panel)
        control_frame.pack(fill=tk.X, pady=5)

        ttk.Label(control_frame, text="Режим просмотра:").pack(side=tk.LEFT, padx=5)

        self.view_mode_var = tk.StringVar(value="history")
        modes = [
            ("История измерений и анализа", "history"),
            ("График вибросигнала", "signal_graph"),
            ("График истории состояния", "state_graph")
        ]

        for text, value in modes:
            ttk.Radiobutton(
                control_frame,
                text=text,
                variable=self.view_mode_var,
                value=value,
                command=self.update_db_view
            ).pack(side=tk.LEFT, padx=5)

        ttk.Label(control_frame, text="Фильтр по типу узла:").pack(side=tk.LEFT, padx=(15, 5))

        self.filter_var = tk.StringVar(value="Все")
        filter_combo = ttk.Combobox(
            control_frame,
            textvariable=self.filter_var,
            values=["Все", "Двигатель", "Редуктор", "Турбина"],
            state="readonly",
            width=15
        )
        filter_combo.pack(side=tk.LEFT)
        filter_combo.bind("<<ComboboxSelected>>", lambda e: self.update_db_view())

        self.db_bottom_frame = ttk.LabelFrame(self.center_panel, text="Связанные данные", style="Block.TLabelframe")
        self.db_bottom_frame.pack(fill=tk.BOTH, expand=True)

        self._fill_db_machines()

    def _fill_db_machines(self):
        self.db_machines_tree.delete(*self.db_machines_tree.get_children())

        rows = self.conn.execute("SELECT * FROM machines ORDER BY machine_id").fetchall()
        for row in rows:
            self.db_machines_tree.insert("", tk.END, values=(
                row["machine_id"],
                row["name"],
                row["model"] or "-",
                row["type"] or "-",
                row["status"] or "-"
            ))

    def on_db_machine_select(self, event):
        selected = self.db_machines_tree.selection()
        if not selected:
            return

        values = self.db_machines_tree.item(selected[0])["values"]
        self.current_machine_id = values[0]
        self.update_db_view()

    def update_db_view(self):
        if self.current_frame != "database":
            return

        for widget in self.db_bottom_frame.winfo_children():
            widget.destroy()

        if not self.current_machine_id:
            ttk.Label(self.db_bottom_frame, text="Выберите технику в верхней таблице.").pack(pady=30)
            return

        mode = self.view_mode_var.get()

        if mode == "history":
            self._show_history_view()
        elif mode == "signal_graph":
            self._show_signal_graph()
        elif mode == "state_graph":
            self._show_state_graph()

    # ------------------------------------------------------------------
    # 3.5.5 ИСТОРИЯ ИЗМЕРЕНИЙ И АНАЛИЗА
    # ------------------------------------------------------------------

    def _show_history_view(self):
        filter_type = self.filter_var.get()

        columns = ("time", "unit", "sensor", "state", "confidence", "recommendation")
        tree = ttk.Treeview(self.db_bottom_frame, columns=columns, show="headings", height=15)

        tree.heading("time", text="Дата/время анализа")
        tree.heading("unit", text="Тип узла")
        tree.heading("sensor", text="Датчик")
        tree.heading("state", text="Состояние")
        tree.heading("confidence", text="Уверенность")
        tree.heading("recommendation", text="Рекомендация")

        tree.column("time", width=160)
        tree.column("unit", width=120)
        tree.column("sensor", width=120)
        tree.column("state", width=120)
        tree.column("confidence", width=100)
        tree.column("recommendation", width=300)

        tree.tag_configure("normal", background="#FFFFFF")
        tree.tag_configure("wear", background="#FFF4CC")
        tree.tag_configure("fault", background="#FFD6D6")

        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        cursor = self.conn.cursor()
        units = cursor.execute(
            "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
            (self.current_machine_id,)
        ).fetchall()

        for unit in units:
            if filter_type != "Все" and unit["unit_type"] != filter_type:
                continue

            sensor = cursor.execute(
                "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                (unit["unit_id"],)
            ).fetchone()

            if not sensor:
                continue

            history = get_analysis_history(self.conn, sensor["sensor_id"])

            for item in history:
                state_name = item["state_name_ru"]
                tag = self._get_state_tag(state_name)

                recommendation = item["recommendation"] or "-"
                if len(recommendation) > 60:
                    recommendation = recommendation[:60] + "..."

                tree.insert("", tk.END, values=(
                    item["analysis_time"],
                    unit["unit_type"],
                    sensor["name"],
                    state_name,
                    f"{item['average_probability']:.2f}",
                    recommendation
                ), tags=(tag,))

    # ------------------------------------------------------------------
    # 3.5.6 ГРАФИК ВИБРАЦИОННОГО СИГНАЛА
    # ------------------------------------------------------------------

    def _show_signal_graph(self):
        cursor = self.conn.cursor()

        sensor = cursor.execute("""
            SELECT s.*
            FROM sensors s
            JOIN units u ON s.unit_id = u.unit_id
            WHERE u.machine_id = ?
            ORDER BY s.sensor_id
            LIMIT 1
        """, (self.current_machine_id,)).fetchone()

        if not sensor:
            ttk.Label(self.db_bottom_frame, text="Для выбранной техники нет датчиков.").pack(pady=30)
            return

        values = get_sensor_values(self.conn, sensor["sensor_id"])

        if not values:
            ttk.Label(self.db_bottom_frame, text="Нет вибрационных измерений для построения графика.").pack(pady=30)
            return

        display_values = values[-500:] if len(values) > 500 else values

        fig, ax = plt.subplots(figsize=(10, 4))
        ax.plot(display_values, linewidth=0.8)
        ax.set_title(f"График вибрационного сигнала: {sensor['name']}")
        ax.set_xlabel("Номер отсчета")
        ax.set_ylabel("Амплитуда")
        ax.grid(True, alpha=0.3)

        canvas = FigureCanvasTkAgg(fig, master=self.db_bottom_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # ------------------------------------------------------------------
    # 3.5.7 ГРАФИК ИСТОРИИ СОСТОЯНИЯ
    # ------------------------------------------------------------------

    def _show_state_graph(self):
        cursor = self.conn.cursor()

        units = cursor.execute(
            "SELECT * FROM units WHERE machine_id = ? ORDER BY unit_id",
            (self.current_machine_id,)
        ).fetchall()

        if not units:
            ttk.Label(self.db_bottom_frame, text="Нет узлов для построения графика состояния.").pack(pady=30)
            return

        fig, ax = plt.subplots(figsize=(10, 4))

        has_data = False

        for unit in units:
            sensor = cursor.execute(
                "SELECT * FROM sensors WHERE unit_id = ? LIMIT 1",
                (unit["unit_id"],)
            ).fetchone()

            if not sensor:
                continue

            history = get_analysis_history(self.conn, sensor["sensor_id"])

            if not history:
                continue

            has_data = True
            history.sort(key=lambda x: x["analysis_time"])

            times = [h["analysis_time"][11:16] for h in history]
            levels = [self.STATE_LEVELS.get(h["dominant_state"], 0) for h in history]

            ax.plot(times, levels, marker="o", label=f"{unit['name']} ({unit['unit_type']})")

        if not has_data:
            ttk.Label(self.db_bottom_frame, text="Нет результатов анализа для построения графика.").pack(pady=30)
            return

        ax.set_title("График истории состояния узлов")
        ax.set_xlabel("Время")
        ax.set_ylabel("Состояние")
        ax.set_yticks([0, 1, 2])
        ax.set_yticklabels(["Норма", "Износ", "Сильный износ"])
        ax.grid(True, alpha=0.3)
        ax.legend()
        plt.xticks(rotation=45)

        canvas = FigureCanvasTkAgg(fig, master=self.db_bottom_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    # ------------------------------------------------------------------
    # ЗАГРУЗКА CSV
    # ------------------------------------------------------------------

    def load_csv_data(self):
        file_path = filedialog.askopenfilename(
            title="Выберите CSV-файл",
            filetypes=[("CSV files", "*.csv")]
        )

        if not file_path:
            return

        try:
            df = load_sensor_csv(file_path)
            cursor = self.conn.cursor()

            sensor_ids = df["sensor_id"].unique()
            unknown_sensors = []

            for sid in sensor_ids:
                exists = cursor.execute(
                    "SELECT 1 FROM sensors WHERE sensor_id = ?",
                    (int(sid),)
                ).fetchone()

                if not exists:
                    unknown_sensors.append(str(sid))

            if unknown_sensors:
                messagebox.showwarning(
                    "Предупреждение",
                    "Неизвестные датчики: " + ", ".join(unknown_sensors)
                )
                df = df[~df["sensor_id"].isin([int(s) for s in unknown_sensors])]

            if df.empty:
                messagebox.showerror("Ошибка", "Нет данных для загрузки.")
                return

            inserted = 0

            for _, row in df.iterrows():
                cursor.execute(
                    "INSERT INTO sensor_readings (sensor_id, timestamp, value) VALUES (?, ?, ?)",
                    (int(row["sensor_id"]), row["timestamp"].isoformat(), float(row["value"]))
                )
                inserted += 1

            self.conn.commit()

            messagebox.showinfo("Готово", f"Загружено записей: {inserted}")

            self.refresh_object_tree()
            self.refresh_main_table()
            self.refresh_notifications()

        except Exception as e:
            messagebox.showerror("Ошибка загрузки", str(e))

    # ------------------------------------------------------------------
    # ЗАПУСК АНАЛИЗА
    # ------------------------------------------------------------------

    def run_analysis(self):
        cursor = self.conn.cursor()
        sensors = cursor.execute("SELECT sensor_id FROM sensors ORDER BY sensor_id").fetchall()

        if not sensors:
            messagebox.showwarning("Внимание", "Нет датчиков для анализа.")
            return

        analyzed = 0
        errors = []

        for sensor in sensors:
            sensor_id = sensor["sensor_id"]

            try:
                values = get_sensor_values(self.conn, sensor_id)

                if len(values) < 128:
                    continue

                model = load_model_for_sensor(self.conn, sensor_id)
                results = analyze_signal_segment(self.conn, model, sensor_id, values)

                if results:
                    analyzed += 1

            except Exception as e:
                errors.append(f"Датчик {sensor_id}: {str(e)}")

        if errors:
            messagebox.showwarning(
                "Анализ выполнен частично",
                f"Проанализировано датчиков: {analyzed}\n\nОшибки:\n" + "\n".join(errors[:5])
            )
        else:
            messagebox.showinfo("Готово", f"Анализ выполнен для датчиков: {analyzed}")

        self.refresh_object_tree()
        self.refresh_main_table()
        self.refresh_notifications()

    # ------------------------------------------------------------------
    # ОПОВЕЩЕНИЯ
    # ------------------------------------------------------------------

    def refresh_notifications(self):
        self.notifications_listbox.delete(0, tk.END)

        rows = self.conn.execute("""
            SELECT notification_time, message
            FROM dispatcher_notifications
            ORDER BY notification_id DESC
            LIMIT 30
        """).fetchall()

        if not rows:
            self.notifications_listbox.insert(tk.END, "Новых оповещений нет")
            return

        for row in rows:
            time_str = row["notification_time"][11:16] if row["notification_time"] else ""
            message = row["message"] or ""

            if len(message) > 70:
                message = message[:70] + "..."

            self.notifications_listbox.insert(tk.END, f"{time_str}: {message}")

    # ------------------------------------------------------------------
    # ЗАКРЫТИЕ
    # ------------------------------------------------------------------

    def on_closing(self):
        self.conn.close()
        self.destroy()


if __name__ == "__main__":
    app = MonitoringApp()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()